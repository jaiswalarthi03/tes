import pandas as pd
import numpy as np
import hashlib
import json
import time
from typing import Dict, List, Tuple, Any
from databricks import sql
from config import DATABRICKS_SERVER, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN, ARCHITECTURAL_STANDARDS

class ToTNode:
    """
    Node in the Tree-of-Table structure.
    node_type: 'database', 'table', or 'chunk'
    name: node name
    metadata: dict with context (columns, stats, etc.)
    children: list of child nodes
    parent: parent node
    summary: AI/aggregation result for this node
    error: error message if analysis failed
    """
    def __init__(self, node_type, name, metadata=None, children=None, parent=None):
        self.node_type = node_type
        self.name = name
        self.metadata = metadata or {}
        self.children = children or []
        self.parent = parent
        self.summary = None
        self.error = None

    def add_child(self, child):
        self.children.append(child)
        child.parent = self

    def is_leaf(self):
        return self.node_type == 'chunk'

    def to_dict(self):
        """Return a dict representation for UI drilldown."""
        return {
            'node_type': self.node_type,
            'name': self.name,
            'metadata': self.metadata,
            'summary': self.summary,
            'error': self.error,
            'children': [c.to_dict() for c in self.children]
        }

class TreeOfTablesAnalyzer:
    """
    Implements full ToT methodology for large-scale table analysis.
    - Breadth-first for decomposition (tree build)
    - Depth-first for aggregation (results up the tree)
    - Chunk columns by 10, only send metadata to AI
    - Robust for 1000+ tables x 10,000 columns
    - Preserves context and relationships at every node
    - Handles errors, logs, and progress
    """
    
    def __init__(self):
        self.connection = None
        self.chunks_cache = {}
        self.embeddings_cache = {}
        self.tree_structure = {}
        
    def connect_to_databricks(self):
        """Establish connection to Databricks SQL warehouse"""
        try:
            self.connection = sql.connect(
                server_hostname=DATABRICKS_SERVER,
                http_path=DATABRICKS_HTTP_PATH,
                access_token=DATABRICKS_TOKEN
            )
            return True
        except Exception as e:
            print(f"❌ Databricks error: {str(e)}")
            return False
    
    def close_connection(self):
        """Close Databricks connection"""
        if self.connection:
            self.connection.close()
    
    def load_table_from_databricks(self, catalog: str, schema: str, table: str, limit: int = 1000) -> pd.DataFrame:
        """
        Load table data from Databricks with chunking for large tables
        """
        if not self.connection:
            if not self.connect_to_databricks():
                raise Exception("Failed to connect to Databricks")
        try:
            if self.connection is None:
                raise Exception("No database connection available")
            cursor = self.connection.cursor()
            # Get column information
            cursor.execute(f"DESCRIBE {catalog}.{schema}.{table}")
            columns_info = cursor.fetchall()
            # Get sample data with limit
            query = f"SELECT * FROM {catalog}.{schema}.{table} LIMIT {limit}"
            print(f"[ToT] Executing SQL: {query}")
            try:
                cursor.execute(query)
            except Exception as e:
                print(f"[ToT] ERROR executing SQL: {query}")
                print(f"[ToT] Exception: {e}")
                import traceback
                traceback.print_exc()
                raise Exception(f"SQL execution failed for {catalog}.{schema}.{table}: {e}")
            # Convert to DataFrame
            df = pd.DataFrame(cursor.fetchall())
            if not df.empty:
                column_names = [col[0] for col in columns_info if col[0] and not col[0].startswith('#')]
                if len(column_names) == len(df.columns):
                    df.columns = column_names
            cursor.close()
            return df
        except Exception as e:
            print(f"❌ Table error: {catalog}.{schema}.{table} - {e}")
            import traceback
            traceback.print_exc()
            raise Exception(f"Failed to load table {catalog}.{schema}.{table}: {e}")
    
    def normalize_table(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Normalize table structure as per Tree-of-Table methodology
        
        Args:
            df: Input DataFrame
            
        Returns:
            Normalized DataFrame
        """
        # Transpose if columns > rows (wide table)
        if df.shape[1] > df.shape[0]:
            df = df.transpose()
        
        # Sort rows and columns for consistency
        df = df.sort_index(axis=0).sort_index(axis=1)
        
        # Clean data types and handle missing values
        for col in df.columns:
            if df[col].dtype == 'object':
                df[col] = df[col].astype(str).fillna('')
        
        return df
    
    def table_to_chunks(self, df: pd.DataFrame, chunk_size: int = 1000, preserve_context: bool = True) -> Tuple[List[str], List[Dict]]:
        """
        Enhanced chunking with context preservation for large tables
        
        Args:
            df: Input DataFrame
            chunk_size: Maximum characters per chunk
            preserve_context: Whether to preserve context across chunks
            
        Returns:
            Tuple of (chunks, metadata)
        """
        chunks = []
        metadata = []
        
        # For large tables, use adaptive chunking
        if len(df.columns) > 50:  # Large table threshold
            chunk_size = min(chunk_size, 500)  # Smaller chunks for large tables
            preserve_context = True
        
        # Convert DataFrame to CSV text
        text = df.to_csv(index=False)
        lines = text.splitlines()
        
        current_chunk = []
        current_len = 0
        chunk_id = 0
        
        # Enhanced context preservation
        context_summary = self._create_context_summary(df) if preserve_context else ""
        
        for line in lines:
            if current_len + len(line) > chunk_size and current_chunk:
                # Add context to chunk if preserving context
                chunk_content = "\n".join(current_chunk)
                if preserve_context and context_summary:
                    chunk_content = f"# Context Summary\n{context_summary}\n\n# Data\n{chunk_content}"
                
                chunks.append(chunk_content)
                metadata.append({
                    'chunk_id': chunk_id,
                    'chunk_type': 'csv_block',
                    'columns': self._extract_columns_from_chunk(current_chunk),
                    'size': current_len,
                    'context_preserved': preserve_context,
                    'table_shape': f"{df.shape[0]}x{df.shape[1]}",
                    'large_table': len(df.columns) > 50
                })
                chunk_id += 1
                current_chunk = []
                current_len = 0
            
            current_chunk.append(line)
            current_len += len(line)
        
        # Add remaining chunk
        if current_chunk:
            chunk_content = "\n".join(current_chunk)
            if preserve_context and context_summary:
                chunk_content = f"# Context Summary\n{context_summary}\n\n# Data\n{chunk_content}"
            
            chunks.append(chunk_content)
            metadata.append({
                'chunk_id': chunk_id,
                'chunk_type': 'csv_block',
                'columns': self._extract_columns_from_chunk(current_chunk),
                'size': current_len,
                'context_preserved': preserve_context,
                'table_shape': f"{df.shape[0]}x{df.shape[1]}",
                'large_table': len(df.columns) > 50
            })
        
        return chunks, metadata
    
    def _create_context_summary(self, df: pd.DataFrame) -> str:
        """Create context summary for large tables to preserve relationships"""
        summary = []
        summary.append(f"Table Shape: {df.shape[0]} rows x {df.shape[1]} columns")
        
        # Convert column names to strings to handle integer column names
        column_names = [str(col) for col in df.columns[:10]]
        summary.append(f"Column Names: {', '.join(column_names)}{'...' if len(df.columns) > 10 else ''}")
        
        # Add data type information
        dtypes = df.dtypes.value_counts()
        summary.append(f"Data Types: {dict(dtypes)}")
        
        # Add sample values for key columns
        if len(df.columns) > 0:
            sample_col = df.columns[0]
            sample_values = df[sample_col].dropna().head(3).tolist()
            summary.append(f"Sample {sample_col}: {sample_values}")
        
        return "\n".join(summary)
    
    def _extract_columns_from_chunk(self, chunk_lines: List[str]) -> List[str]:
        """Extract column names from chunk lines"""
        if not chunk_lines:
            return []
        
        # First line should be header
        header_line = chunk_lines[0]
        return [col.strip() for col in header_line.split(',')]
    
    def simple_embedding_simulation(self, text: str) -> np.ndarray:
        """
        Simulate embeddings using hash-based approach
        In production, replace with OpenAI embeddings or sentence-transformers
        """
        # Use the embedding function from search_engine to avoid duplication
        # This function is no longer available, so we'll return a dummy embedding
        # In a real scenario, you'd replace this with a proper embedding generation logic
        # For now, we'll return a dummy array
        return np.array([0.1, 0.2, 0.3]) # Dummy embedding
    
    def build_similarity_index(self, chunks: List[str], metadata_list: List[dict]) -> Any:
        """Build FAISS-based similarity index for chunks"""
        # This function is no longer available, so we'll return a dummy index
        # In a real scenario, you'd replace this with a proper FAISS index building logic
        # For now, we'll return a dummy object
        return {"message": "FAISS index building is not available in this version."}

    def search_similar_chunks(self, query: str, vector_db: Any, top_k: int = 5) -> List[Dict]:
        """Search for similar chunks using FAISS-based VectorDatabase"""
        # This function is no longer available, so we'll return a dummy search result
        # In a real scenario, you'd replace this with a proper search logic
        return [{"chunk": "No similar chunks found for this query.", "similarity": 0.0}]
    
    def build_tree_structure(self, retrieved_chunks: List[Dict], metadata_list: List[Dict]) -> Dict:
        """
        Build hierarchical tree structure from retrieved chunks
        
        Args:
            retrieved_chunks: List of chunk dictionaries
            metadata_list: List of metadata dictionaries
            
        Returns:
            Hierarchical tree structure
        """
        tree = {}
        
        for chunk_data, meta in zip(retrieved_chunks, metadata_list):
            chunk = chunk_data['chunk']
            similarity = chunk_data['similarity']
            
            # Extract table and column information from metadata
            columns = meta.get('columns', [])
            
            # Group by columns (simplified - in real implementation, you'd have table info)
            for col in columns:
                if col not in tree:
                    tree[col] = []
                
                tree[col].append({
                    'content': chunk,
                    'similarity': similarity,
                    'metadata': meta
                })
        
        return tree
    
    def analyze_schema_issues(self, df: pd.DataFrame) -> Dict:
        """
        Analyze schema for denormalization, redundancy, and design issues
        
        Args:
            df: DataFrame to analyze
            
        Returns:
            Dictionary with analysis results
        """
        analysis = {
            'total_columns': len(df.columns),
            'total_rows': len(df),
            'denormalization_issues': [],
            'redundancy_issues': [],
            'design_issues': []
        }
        
        # Check for denormalization (too many columns)
        if len(df.columns) > 100:
            analysis['denormalization_issues'].append({
                'issue': 'High column count',
                'description': f'Table has {len(df.columns)} columns, suggesting possible denormalization',
                'recommendation': 'Consider normalizing into multiple related tables'
            })
        
        # Check for data type issues
        for col in df.columns:
            if df[col].dtype == 'object':
                unique_ratio = df[col].nunique() / len(df)
                if unique_ratio < 0.1:  # Low cardinality
                    analysis['design_issues'].append({
                        'issue': 'Low cardinality column',
                        'column': col,
                        'description': f'Column {col} has low cardinality ({unique_ratio:.2%})',
                        'recommendation': 'Consider if this column is necessary or could be normalized'
                    })
        
        # Check for missing values
        missing_data = df.isnull().sum()
        high_missing_cols = missing_data[missing_data > len(df) * 0.5]
        for col in high_missing_cols.index:
            analysis['design_issues'].append({
                'issue': 'High missing values',
                'column': col,
                'description': f'Column {col} has {high_missing_cols[col]} missing values',
                'recommendation': 'Review data quality and consider if column is necessary'
            })
        
        return analysis
    
    def create_governance_analysis_prompt(self, schema_metadata: Dict, tree_structure: Dict, analysis_type: str = 'governance') -> str:
        """
        Create comprehensive governance analysis prompt using architectural standards
        
        Args:
            schema_metadata: Schema information from Databricks
            tree_structure: Tree-of-Table hierarchical structure
            analysis_type: Type of analysis to perform
            
        Returns:
            Formatted prompt for AI analysis
        """
        # Format schema information
        schema_info = json.dumps(schema_metadata, indent=2)
        tree_info = json.dumps(tree_structure, indent=2)
        
        # Get relevant architectural standards
        standards_info = ""
        for standard_key, standard_data in ARCHITECTURAL_STANDARDS.items():
            standards_info += f"\n## {standard_data['name']}\n"
            standards_info += f"{standard_data['description']}\n"
            standards_info += "Checks:\n"
            for check in standard_data['checks']:
                standards_info += f"- {check}\n"
        
        prompt = f"""
You are a data governance and compliance expert analyzing Databricks tables using Tree-of-Table methodology. 
Provide a comprehensive analysis covering all 20+ architectural standards for data governance and compliance.

## Schema Information:
```json
{schema_info}
```

## Tree-of-Table Hierarchical Structure:
```json
{tree_info}
```

## Architectural Standards to Evaluate:
{standards_info}

## Analysis Requirements:

Please provide a comprehensive governance and compliance analysis that includes:

1. **Data Quality Assessment**
   - Evaluate data completeness, accuracy, consistency, and timeliness
   - Identify data quality issues and recommendations

2. **Security & Privacy Analysis**
   - Assess data security measures and privacy compliance
   - Identify potential security gaps and privacy risks

3. **Performance & Scalability Review**
   - Analyze query performance and scalability considerations
   - Provide optimization recommendations

4. **Compliance Evaluation**
   - Check adherence to industry standards (SOX, HIPAA, GDPR, etc.)
   - Identify compliance gaps and remediation steps

5. **Data Governance Assessment**
   - Evaluate data ownership, stewardship, and lifecycle management
   - Assess governance framework implementation

6. **Technical Architecture Review**
   - Analyze data modeling, engineering practices, and operational procedures
   - Provide architectural improvement recommendations

7. **Risk Assessment**
   - Identify potential risks and mitigation strategies
   - Provide risk scoring and prioritization

Format your response as HTML with:
- Use <h1>, <h2>, <h3> for headings
- Use <ul>, <ol>, <li> for lists
- Use <table>, <tr>, <th>, <td> for tabular data
- Use <code> and <pre> for examples
- Add emojis for visual appeal (e.g., 🔒, 📊, ⚠️, ✅, 💡)
- Use color coding: <span style="color: red;"> for issues, <span style="color: green;"> for good practices

Make your response comprehensive, actionable, and focused on governance and compliance standards.
"""
        
        return prompt
    
    def analyze_multiple_tables(self, table_list: List[Dict]) -> Dict:
        """
        Enhanced analysis of multiple tables using Tree-of-Table methodology
        with improved handling of large tables and context preservation
        
        Args:
            table_list: List of table dictionaries with catalog, schema, table info
            
        Returns:
            Comprehensive analysis results with performance metrics
        """
        all_results = {
            'tables_analyzed': [],
            'tree_structures': {},
            'schema_issues': {},
            'governance_analysis': {},
            'recommendations': [],
            'performance_metrics': {
                'total_tables': len(table_list),
                'large_tables': 0,
                'total_chunks': 0,
                'avg_chunk_size': 0,
                'context_preservation_score': 0.0
            }
        }
        
        total_chunks = 0
        total_chunk_size = 0
        context_scores = []
        
        for table_info in table_list:
            catalog = table_info['catalog']
            schema = table_info['schema']
            table = table_info['name']
            
            print(f"🔍 {catalog}.{schema}.{table}")
            
            try:
                # Load and normalize table with adaptive limits for large tables
                df = self.load_table_from_databricks(catalog, schema, table)
                df_normalized = self.normalize_table(df)
                
                # Determine if this is a large table
                is_large_table = len(df.columns) > 50
                if is_large_table:
                    all_results['performance_metrics']['large_tables'] += 1
                    print(f"  📊 Large table: {len(df.columns)} columns")
                
                # Enhanced chunking with context preservation
                chunk_size = 500 if is_large_table else 1000
                chunks, metadata = self.table_to_chunks(df_normalized, chunk_size, preserve_context=True)
                
                # Update performance metrics
                total_chunks += len(chunks)
                total_chunk_size += sum(m.get('size', 0) for m in metadata)
                
                # Calculate context preservation score
                context_preserved_chunks = sum(1 for m in metadata if m.get('context_preserved', False))
                context_score = context_preserved_chunks / len(metadata) if metadata else 0.0
                context_scores.append(context_score)
                
                # Build similarity index with enhanced embeddings
                # vector_db = self.build_similarity_index(chunks, metadata) # This line is removed
                
                # Analyze schema issues with governance focus
                schema_analysis = self.analyze_schema_issues(df_normalized)
                
                # Enhanced tree structure building with multiple queries
                tree_structure = {}
                queries = [
                    f"analyze {table} for governance compliance",
                    f"data quality assessment for {table}",
                    f"security and privacy analysis of {table}",
                    f"performance optimization for {table}"
                ]
                
                # for query in queries: # This loop is removed
                #     similar_chunks = self.search_similar_chunks(query, vector_db, top_k=3) # This line is removed
                #     query_results = self.build_tree_structure(similar_chunks, metadata) # This line is removed
                #     tree_structure[query] = query_results # This line is removed
                
                # Store comprehensive results
                table_key = f"{catalog}.{schema}.{table}"
                all_results['tables_analyzed'].append(table_key)
                all_results['tree_structures'][table_key] = tree_structure
                all_results['schema_issues'][table_key] = schema_analysis
                
                # Add table-specific recommendations
                table_recommendations = self._generate_table_recommendations(
                    df_normalized, schema_analysis, is_large_table, context_score
                )
                all_results['recommendations'].extend(table_recommendations)
                
                print(f"✅ {table_key} ({len(chunks)} chunks)")
                
            except Exception as e:
                print(f"❌ {catalog}.{schema}.{table}")
                all_results['recommendations'].append({
                    'type': 'error',
                    'table': f"{catalog}.{schema}.{table}",
                    'message': f"Analysis failed: {str(e)}",
                    'severity': 'high'
                })
        
        # Calculate final performance metrics
        all_results['performance_metrics']['total_chunks'] = total_chunks
        all_results['performance_metrics']['avg_chunk_size'] = total_chunk_size / total_chunks if total_chunks > 0 else 0
        all_results['performance_metrics']['context_preservation_score'] = sum(context_scores) / len(context_scores) if context_scores else 0.0
        
        print(f"📊 Summary: {len(all_results['tables_analyzed'])} tables, {total_chunks} chunks")
        
        return all_results
    
    def _generate_table_recommendations(self, df: pd.DataFrame, schema_analysis: Dict, 
                                      is_large_table: bool, context_score: float) -> List[Dict]:
        """Generate table-specific recommendations based on analysis results"""
        recommendations = []
        
        # Large table recommendations
        if is_large_table:
            recommendations.append({
                'type': 'performance',
                'table': 'large_table_optimization',
                'message': 'Consider partitioning and clustering for better performance',
                'severity': 'medium',
                'priority': 'high'
            })
            
            if context_score < 0.8:
                recommendations.append({
                    'type': 'context_preservation',
                    'table': 'context_enhancement',
                    'message': 'Improve context preservation in chunking strategy',
                    'severity': 'medium',
                    'priority': 'medium'
                })
        
        # Schema quality recommendations
        if schema_analysis.get('missing_primary_keys', 0) > 0:
            recommendations.append({
                'type': 'data_quality',
                'table': 'primary_key_definition',
                'message': f"Define primary keys for {schema_analysis['missing_primary_keys']} tables",
                'severity': 'high',
                'priority': 'high'
            })
        
        # Data type optimization
        if schema_analysis.get('suboptimal_data_types', 0) > 0:
            recommendations.append({
                'type': 'performance',
                'table': 'data_type_optimization',
                'message': f"Optimize {schema_analysis['suboptimal_data_types']} data types for better performance",
                'severity': 'medium',
                'priority': 'medium'
            })
        
        return recommendations
    
    def create_large_test_tables(self, catalog: str, schema: str) -> bool:
        """
        Create large test tables in Databricks for testing Tree-of-Table methodology
        
        Args:
            catalog: Target catalog
            schema: Target schema
            
        Returns:
            Success status
        """
        if not self.connection:
            if not self.connect_to_databricks():
                return False
        
        try:
            if self.connection is None:
                raise Exception("No database connection available")
            
            cursor = self.connection.cursor()
            
            # Create large consent table with 300+ columns
            consent_columns = []
            for i in range(1, 301):
                consent_columns.append(f"consent_col_{i:03d} STRING")
            
            consent_table_sql = f"""
            CREATE TABLE IF NOT EXISTS {catalog}.{schema}.large_consent_table (
                id BIGINT,
                {', '.join(consent_columns)}
            )
            """
            
            # Create large patient table with 300+ columns
            patient_columns = []
            for i in range(1, 301):
                patient_columns.append(f"patient_col_{i:03d} STRING")
            
            patient_table_sql = f"""
            CREATE TABLE IF NOT EXISTS {catalog}.{schema}.large_patient_table (
                id BIGINT,
                {', '.join(patient_columns)}
            )
            """
            
            # Execute table creation
            cursor.execute(consent_table_sql)
            cursor.execute(patient_table_sql)
            
            # Insert sample data (simplified for demo)
            for table_name in ['large_consent_table', 'large_patient_table']:
                for row_id in range(1, 5):  # 4 rows per table
                    values = [row_id] + [f"sample_data_{row_id}_{col}" for col in range(1, 301)]
                    placeholders = ", ".join(["?"] * 301)
                    insert_sql = f"INSERT INTO {catalog}.{schema}.{table_name} VALUES ({placeholders})"
                    cursor.execute(insert_sql, values)
            
            if self.connection is not None:
                self.connection.commit()
            cursor.close()
            
            print(f"✓ Created test tables in {catalog}.{schema}")
            return True
            
        except Exception as e:
            print(f"✗ Error creating test tables: {str(e)}")
            return False 

    def chunk_columns_by_count(self, columns: List[str], chunk_size: int = 10) -> List[List[str]]:
        """
        Split columns into chunks of chunk_size (default 10).
        """
        return [columns[i:i+chunk_size] for i in range(0, len(columns), chunk_size)]

    def extract_column_metadata(self, df: pd.DataFrame, columns: List[str]) -> List[Dict[str, Any]]:
        """
        Extract metadata for a list of columns from a DataFrame.
        """
        meta = []
        for col in columns:
            meta.append({
                'name': col,
                'dtype': str(df[col].dtype),
                'null_count': int(df[col].isnull().sum()),
                'unique_count': int(df[col].nunique()),
                'sample_values': df[col].dropna().unique()[:3].tolist()
            })
        return meta

    def build_tot_tree(self, tables: List[Dict[str, Any]], dataframes: Dict[str, pd.DataFrame], progress_callback=None) -> ToTNode:
        """
        Build the Tree-of-Table structure for all tables.
        Returns the root node (database).
        Uses breadth-first decomposition.
        """
        root = ToTNode('database', 'database_root')
        for idx, table_info in enumerate(tables):
            table_name = f"{table_info['catalog']}.{table_info['schema']}.{table_info['name']}"
            df = dataframes[table_name]
            table_node = ToTNode('table', table_name, metadata={'n_rows': len(df), 'n_cols': len(df.columns)})
            columns = list(df.columns)
            col_chunks = self.chunk_columns_by_count(columns, 10)
            for cidx, chunk in enumerate(col_chunks):
                chunk_meta = self.extract_column_metadata(df, chunk)
                chunk_node = ToTNode('chunk', f"{table_name}_chunk_{cidx}", metadata={'columns': chunk_meta})
                table_node.add_child(chunk_node)
            root.add_child(table_node)
            if progress_callback:
                progress_callback(f"Built tree for table {idx+1}/{len(tables)}: {table_name}")
        return root

    def analyze_chunk_with_ai(self, chunk_node: ToTNode, ai_analyze_func, analysis_type, progress_callback=None):
        """
        Send chunk metadata to AI and store the summary in the node.
        If AI fails, store error and continue.
        """
        try:
            chunk_node.summary = ai_analyze_func(chunk_node.metadata['columns'], analysis_type)
        except Exception as e:
            chunk_node.summary = None
            chunk_node.error = str(e)
        if progress_callback:
            progress_callback(f"Analyzed chunk: {chunk_node.name}")

    def aggregate_table(self, table_node: ToTNode, progress_callback=None):
        """
        Aggregate all chunk summaries into a table summary, always including table metadata, code analysis, and chunked analysis for every object.
        """
        summaries = []
        errors = []
        for child in table_node.children:
            if child.summary is not None:
                summaries.append(child.summary)
            if child.error:
                errors.append({'chunk': child.name, 'error': child.error})
        # Always include all metadata and code analysis if present
        table_summary = {
            'table': table_node.name,
            'chunk_summaries': summaries,
            'errors': errors
        }
        for key in ['view_code', 'code_analysis', 'schema', 'properties', 'detail']:
            if key in table_node.metadata and table_node.metadata[key]:
                table_summary[key] = table_node.metadata[key]
        table_node.summary = table_summary
        if progress_callback:
            progress_callback(f"Aggregated table: {table_node.name}")

    def aggregate_database(self, root_node: ToTNode, progress_callback=None):
        """
        Aggregate all table summaries into a database summary.
        """
        summaries = []
        errors = []
        for child in root_node.children:
            if child.summary is not None:
                summaries.append(child.summary)
            if child.error:
                errors.append({'table': child.name, 'error': child.error})
        root_node.summary = {
            'database': root_node.name,
            'table_summaries': summaries,
            'errors': errors
        }
        if progress_callback:
            progress_callback(f"Aggregated database root")

    def tot_full_analysis(self, tables: List[Dict[str, Any]], dataframes: Dict[str, pd.DataFrame], ai_analyze_func, analysis_type, progress_callback=None, table_metadatas=None) -> Dict:
        """
        Full ToT analysis pipeline:
        - Build tree (breadth-first)
        - Analyze each chunk (leaf) with AI (can be async/batch in future)
        - Aggregate up the tree (depth-first)
        - Returns the root node's summary (cumulative answer) and full tree for UI drilldown
        """
        root = self.build_tot_tree(tables, dataframes, progress_callback)
        # Analyze all chunks (leaf nodes)
        for table_node in root.children:
            table_metadata = None
            view_code = None
            if table_metadatas and table_node.name in table_metadatas:
                table_metadata = table_metadatas[table_node.name]
                view_code = table_metadata.get('view_code')
                # Attach view_code to table_node metadata for summary
                if view_code:
                    table_node.metadata['view_code'] = view_code
            for chunk_node in table_node.children:
                # Attach view_code to chunk metadata for LLM context
                if view_code:
                    chunk_node.metadata['view_code'] = view_code
                # Patch: pass table_metadata to ai_analyze_func
                chunk_node.summary = ai_analyze_func(chunk_node.metadata['columns'], analysis_type, table_metadata=table_metadata)
            self.aggregate_table(table_node, progress_callback)
        self.aggregate_database(root, progress_callback)
        # Attach all view_codes to root summary for final output
        if hasattr(root, 'summary') and root.summary:
            root.summary['view_codes'] = {}
            for table_node in root.children:
                if 'view_code' in table_node.metadata:
                    root.summary['view_codes'][table_node.name] = table_node.metadata['view_code']
        return {
            'summary': root.summary,
            'tree': root.to_dict()
        }

# Example AI analysis function (to be replaced with real AI call)
def dummy_ai_analyze_func(chunk_metadata, analysis_type: str):
    # Summarize metadata for demo
    return {
        'n_columns': len(chunk_metadata),
        'columns': [col['name'] for col in chunk_metadata],
        'nulls': sum(col['null_count'] for col in chunk_metadata)
    }

# Usage example (to be integrated into your main workflow):
# analyzer = TreeOfTablesAnalyzer()
# tables = [{...}, ...]  # List of table info dicts
# dataframes = {table_name: pd.DataFrame, ...}
# result = analyzer.tot_full_analysis(tables, dataframes, dummy_ai_analyze_func)
# print(json.dumps(result, indent=2)) 