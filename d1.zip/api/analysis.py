import json
import datetime
import time
from typing import List, Dict, Any, Optional
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import db
import ai
from analyzer import TreeOfTablesAnalyzer
from .db import db_manager
import traceback
from ai import is_safe_for_llm, chunk_and_analyze, LLM_HTML_SUFFIX
from client import get_spark_assist_analysis

# Strict LLM guardrails for all prompts
STRICT_LLM_GUARDRAILS = (
    "Instructions: "
    "- Use clear, neutral, and business-appropriate language. "
    "- Do not use creative writing, emojis, exclamation marks, or informal expressions. "
    "- Do not use color, bold, or excessive formatting. "
    "- Structure the summary with short bullet points or brief paragraphs. "
    "- Focus only on key findings and actionable recommendations. "
    "- Do not include background, context, or unnecessary details. "
    "- Keep the summary as short as possible while remaining complete. "
    "- Do not repeat or parrot input text. "
    "- Do not add any special characters, quotes, backticks, or non-ASCII symbols. "
    "- Do not invent or hallucinate data; only summarize what is present. "
    "- Use only standard English letters, numbers, and basic punctuation. "
    "- Do not include any markdown, code blocks, or formatting except for <ul>, <li>, <p>. "
    "- Do not add any emojis or decorative symbols. "
    "- Do not repeat the same recommendation or summary point. "
    "- If a field is missing or unknown, state 'Not available' or omit it. "
    "- Output must be concise, factual, and business-like. "
)

class AnalysisService:
    def __init__(self):
        self.tree_analyzer = TreeOfTablesAnalyzer()

    def run_analysis(self, selected_tables: List[Dict], analysis_type: str, sql_query: Optional[str] = None) -> Dict[str, Any]:
        debug_logs = []
        def log(msg):
            print(msg)
            debug_logs.append(str(msg))
        try:
            print("🚀 Starting ToT Tree-of-Table Analysis...")
            def safe_json(obj):
                try:
                    return json.dumps(obj, indent=2)
                except TypeError:
                    if hasattr(obj, 'dict'):
                        return json.dumps(obj.dict(), indent=2)
                    elif isinstance(obj, list):
                        return json.dumps([o.dict() if hasattr(o, 'dict') else o for o in obj], indent=2)
                    else:
                        return str(obj)
            print(f"Selected tables received: {safe_json(selected_tables)}")
            selected_tables = [t.dict() if not isinstance(t, dict) and hasattr(t, 'dict') else t for t in selected_tables]

            print("📡 Connecting to Databricks...")
            if not db.test_connection():
                return {
                    "success": False,
                    "error": "Failed to connect to Databricks",
                    "debug_logs": debug_logs
                }

            print(" Loading Table Data for ToT Analysis...")
            dataframes = {}
            tables_for_tot = []
            table_metadatas = {}
            for table_info in selected_tables:
                if isinstance(table_info, dict):
                    if 'catalog' in table_info and 'schema_name' in table_info and 'name' in table_info:
                        catalog_name = table_info['catalog']
                        schema_name = table_info['schema_name']
                        table_name = table_info['name']
                        full_name = f"{catalog_name}.{schema_name}.{table_name}"
                        tables_for_tot.append({'catalog': catalog_name, 'schema': schema_name, 'name': table_name})
                        print(f"  📊 Loading {full_name} as DataFrame...")
                        try:
                            df = self.tree_analyzer.load_table_from_databricks(catalog_name, schema_name, table_name, limit=1000)
                            dataframes[full_name] = df
                            schema_info = db.execute_sql_statement(f"DESCRIBE TABLE {catalog_name}.{schema_name}.{table_name}")
                            tbl_properties = db.execute_sql_statement(f"SHOW TBLPROPERTIES {catalog_name}.{schema_name}.{table_name}")
                            table_type = None
                            type_response = db.execute_sql_statement(f"SELECT table_type FROM {catalog_name}.information_schema.tables WHERE table_schema = '{schema_name}' AND table_name = '{table_name}'")
                            if type_response and 'result' in type_response and 'data_array' in type_response['result'] and len(type_response['result']['data_array']) > 0:
                                table_type = type_response['result']['data_array'][0][0]
                            if table_type == 'TABLE':
                                detail_info = db.execute_sql_statement(f"DESCRIBE DETAIL {catalog_name}.{schema_name}.{table_name}")
                            else:
                                detail_info = {'message': 'DESCRIBE DETAIL skipped for views/materialized views'}
                            is_mv_or_view = (
                                (table_type is not None and table_type.replace('_', ' ').upper() in ('VIEW', 'MATERIALIZED VIEW'))
                                or table_name.startswith('__materialization_mat_')
                            )
                            view_code = None
                            code_analysis = None
                            if is_mv_or_view:
                                show_create = f"SHOW CREATE TABLE {catalog_name}.{schema_name}.{table_name}"
                                try:
                                    code_response = db.execute_sql_statement(show_create, use_cache=False)
                                except Exception:
                                    code_response = None
                                if not (code_response and 'result' in code_response and 'data_array' in code_response['result']):
                                    show_create_view = f"SHOW CREATE VIEW {catalog_name}.{schema_name}.{table_name}"
                                    try:
                                        code_response = db.execute_sql_statement(show_create_view, use_cache=False)
                                    except Exception:
                                        code_response = None
                                if code_response and 'result' in code_response and 'data_array' in code_response['result']:
                                    view_code = code_response['result']['data_array'][0][0]
                                    if not is_safe_for_llm(view_code, "", ""):
                                        code_analysis = chunk_and_analyze(
                                            view_code,
                                            get_spark_assist_analysis,
                                            prompt_prefix=(
                                                STRICT_LLM_GUARDRAILS +
                                                "You are a database expert. Analyze the following SQL definition.\n"
                                                "- Identify any issues, anti-patterns, or unnecessary complexity (e.g., redundant CTEs, window functions, poor naming).\n"
                                                "- Provide clear, actionable recommendations for improvement.\n"
                                                "- Do not repeat the SQL code.\n"
                                                "- Only base your analysis on the SQL code below.\n"
                                            ),
                                            label="SQL Definition",
                                            llm_suffix=LLM_HTML_SUFFIX,
                                            word_limit=2000,
                                            overlap=50
                                        )
                                    else:
                                        mv_sql_analysis_prompt = (
                                            STRICT_LLM_GUARDRAILS +
                                            f"You are a database expert. Analyze the following SQL definition.\n"
                                            "- Identify any issues, anti-patterns, or unnecessary complexity (e.g., redundant CTEs, window functions, poor naming).\n"
                                            "- Provide clear, actionable recommendations for improvement.\n"
                                            "- Do not repeat the SQL code.\n"
                                            "- Only base your analysis on the SQL code below.\n\n"
                                            f"[BEGIN SQL]\n{view_code}\n[END SQL]"
                                        )
                                        try:
                                            code_analysis = get_spark_assist_analysis(mv_sql_analysis_prompt)
                                        except Exception as e:
                                            code_analysis = f"[ERROR] LLM call failed: {e}"
                            table_metadata = {
                                'schema': schema_info,
                                'properties': tbl_properties,
                                'detail': detail_info,
                                'view_code': view_code,
                                'code_analysis': code_analysis,
                                'table_type': table_type
                            }
                            # Commented out to hide large JSON output
                            # print(f"\n[DEBUG] table_metadata for {full_name}:\n{json.dumps(table_metadata, indent=2, default=str)}\n")
                            table_metadatas[full_name] = table_metadata
                        except Exception as e:
                            print(f"❌ Failed to load {full_name}: {e}")
                            return {"success": False, "error": f"Failed to load {full_name}: {e}", "debug_logs": debug_logs}
                    else:
                        continue
                else:
                    continue
            num_tables = len(dataframes)
            total_columns = sum(len(df.columns) for df in dataframes.values())
            table_names = list(dataframes.keys())
            tech_summary = f"Dataset contains {num_tables} tables, {total_columns} columns. Example tables: {', '.join(table_names[:3])}{'...' if num_tables > 3 else ''}."
            est_time_sec = int(num_tables * 2 + total_columns * 0.1)
            time_summary = f"Estimated analysis time: {est_time_sec} seconds."
            summary_line = f"<p><b>Analysis Summary:</b> {num_tables} tables, {total_columns} columns analyzed.</p>"
            business_intro_prompt = (
                STRICT_LLM_GUARDRAILS +
                "You are a data analyst. Summarize the schema analysis findings for the dataset in a concise, factual, and professional manner. "
                "Instructions: "
                "- Use clear, neutral, and business-appropriate language. "
                "- Do not use creative writing, emojis, exclamation marks, or informal expressions. "
                "- Do not use color, bold, or excessive formatting. "
                "- Structure the summary with short bullet points or brief paragraphs. "
                "- Focus only on key findings and actionable recommendations. "
                "- Do not include background, context, or unnecessary details. "
                "- Keep the summary as short as possible while remaining complete. "
                "- Do not repeat or parrot input text. "
                "- Do not add any special characters, quotes, backticks, or non-ASCII symbols. "
                "- Do not invent or hallucinate data; only summarize what is present. "
                "- Use only standard English letters, numbers, and basic punctuation. "
                "- Do not include any markdown, code blocks, or formatting except for <ul>, <li>, <p>. "
                "- Do not add any emojis or decorative symbols. "
                "- Do not repeat the same recommendation or summary point. "
                "- If a field is missing or unknown, state 'Not available' or omit it. "
                "- Output must be concise, factual, and business-like. "
                "Example Output: "
                "<p>Bakehouse Dataset Schema Analysis – Key Findings</p>\n<ul>\n<li>The sales_transactions table stores raw credit card numbers; replace with tokenization or remove this field.</li>\n<li>Columns unitPrice and totalPrice should use the DECIMAL type for monetary accuracy.</li>\n<li>Add foreign key constraints to customerID and franchiseID in sales_transactions to enforce referential integrity.</li>\n<li>Add comments to all columns for clarity and maintainability.</li>\n<li>Consider using ENUM types for columns with a limited set of values (e.g., size).</li>\n<li>Implement data validation and check constraints where appropriate.</li>\n<li>Add indexes to frequently queried columns to improve performance.</li>\n</ul>"
            )
            time.sleep(5)
            business_intro = get_spark_assist_analysis(business_intro_prompt)
            dataset_summary = f"{summary_line}{business_intro.strip()} {tech_summary} {time_summary}"

            import time as _time
            real_start_time = _time.time()
            print("🌳 Building ToT Tree and Running Chunked AI Analysis...")
            progress_log = []
            def progress_callback(msg):
                print(msg)
                progress_log.append(msg)
            tot_result = self.tree_analyzer.tot_full_analysis(
                tables_for_tot, dataframes, ai.ai_analyze_chunk_metadata, analysis_type, progress_callback, table_metadatas=table_metadatas
            )
            real_end_time = _time.time()
            real_elapsed_sec = real_end_time - real_start_time
            real_elapsed_str = f"Actual analysis time: {real_elapsed_sec:.1f} seconds."
            print("📊 Compiling ToT Results...")
            all_chunk_summaries = []
            for table_summary in tot_result['summary']['table_summaries']:
                if 'chunk_summaries' in table_summary:
                    all_chunk_summaries.extend(table_summary['chunk_summaries'])
            prompt_prefix = (
                STRICT_LLM_GUARDRAILS +
                "You are a data analyst. Given the following chunk analyses and table metadata, write a single, cohesive summary and actionable recommendations. "
                "Instructions: "
                "- Use clear, neutral, and business-appropriate language. "
                "- Do not use creative writing, emojis, exclamation marks, or informal expressions. "
                "- Do not use color, bold, or excessive formatting. "
                "- Structure the summary with short bullet points or brief paragraphs. "
                "- Focus only on key findings and actionable recommendations. "
                "- Do not include background, context, or unnecessary details. "
                "- Keep the summary as short as possible while remaining complete. "
                "- Do not repeat or parrot input text. "
                "- Do not add any special characters, quotes, backticks, or non-ASCII symbols. "
                "- Do not invent or hallucinate data; only summarize what is present. "
                "- Use only standard English letters, numbers, and basic punctuation. "
                "- Do not include any markdown, code blocks, or formatting except for <ul>, <li>, <p>. "
                "- Do not add any emojis or decorative symbols. "
                "- Do not repeat the same recommendation or summary point. "
                "- If a field is missing or unknown, state 'Not available' or omit it. "
                "- Output must be concise, factual, and business-like. "
                "Example Output: "
                "<p>Bakehouse Dataset Schema Analysis – Key Findings</p>\n<ul>\n<li>The sales_transactions table stores raw credit card numbers; replace with tokenization or remove this field.</li>\n<li>Columns unitPrice and totalPrice should use the DECIMAL type for monetary accuracy.</li>\n<li>Add foreign key constraints to customerID and franchiseID in sales_transactions to enforce referential integrity.</li>\n<li>Add comments to all columns for clarity and maintainability.</li>\n<li>Consider using ENUM types for columns with a limited set of values (e.g., size).</li>\n<li>Implement data validation and check constraints where appropriate.</li>\n<li>Add indexes to frequently queried columns to improve performance.</li>\n</ul>\nHere are the chunk analyses and metadata:\n\n"
            )
            chunk_analyses_text = '\n\n'.join(all_chunk_summaries)
            table_metadatas_text = json.dumps(table_metadatas, indent=2)
            if not is_safe_for_llm(chunk_analyses_text + table_metadatas_text, prompt_prefix, LLM_HTML_SUFFIX):
                combined_content = f"Chunk Analyses:\n{chunk_analyses_text}\n\nTable Metadata:\n{table_metadatas_text}"
                dataset_summary = chunk_and_analyze(
                    combined_content,
                    get_spark_assist_analysis,
                    prompt_prefix=prompt_prefix,
                    label="Analysis Results and Metadata",
                    llm_suffix=LLM_HTML_SUFFIX,
                    word_limit=2000,
                    overlap=50
                )
            else:
                summary_prompt = f"{prompt_prefix}{chunk_analyses_text}\n\nTable metadata:\n<pre><code>{table_metadatas_text}</code></pre>" + LLM_HTML_SUFFIX
                time.sleep(5)
                dataset_summary = get_spark_assist_analysis(summary_prompt)
            dataset_summary += f"<br/><b>⏱️ {real_elapsed_str}</b>"
            analysis_result = {
                'analysis_type': analysis_type,
                'tables_analyzed': list(dataframes.keys()),
                'dataset_summary': dataset_summary,
                'tot_tree_summary': tot_result['summary'],
                'tot_tree': tot_result['tree'],
                'progress_log': progress_log,
                'timestamp': datetime.datetime.now().isoformat()
            }
            analysis_id = db_manager.store_analysis_result(
                analysis_type, list(dataframes.keys()), sql_query, analysis_result, None
            )
            return {
                "success": True,
                "analysis_id": analysis_id,
                "results": analysis_result,
                "metrics": None,
                "debug_logs": debug_logs
            }
        except Exception as e:
            print(f"❌ ToT Analysis failed: {str(e)}")
            print(traceback.format_exc())
            return {
                "success": False,
                "error": f"ToT Analysis failed: {str(e)}",
                "debug_logs": debug_logs
            }

    def get_analysis_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get analysis history from database."""
        return db_manager.get_analysis_history(limit)

    def get_analysis_by_id(self, analysis_id: int) -> Optional[Dict[str, Any]]:
        """Get specific analysis result by ID."""
        return db_manager.get_analysis_by_id(analysis_id)

    def delete_analysis(self, analysis_id: int) -> bool:
        """Delete analysis result by ID."""
        return db_manager.delete_analysis(analysis_id)

# Global analysis service instance
analysis_service = AnalysisService() 