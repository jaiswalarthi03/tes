import sqlite3
import datetime
from typing import Optional, Dict, Any, List
from contextlib import contextmanager
import os

DATABASE_PATH = "data.db"

class DatabaseManager:
    def __init__(self, db_path: str = DATABASE_PATH):
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        """Initialize database schema."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Analysis results table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS analysis_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    analysis_type TEXT NOT NULL,
                    table_names TEXT NOT NULL,
                    sql_query TEXT,
                    analysis_result TEXT NOT NULL,
                    metrics TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    status TEXT DEFAULT 'completed'
                )
            """)
            
            # Custom rules table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS custom_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    description TEXT,
                    rule_type TEXT NOT NULL,
                    category TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    query TEXT NOT NULL,
                    active BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Scheduled jobs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS scheduled_jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    description TEXT,
                    catalog TEXT NOT NULL,
                    schema TEXT NOT NULL,
                    tables TEXT NOT NULL,
                    analysis_types TEXT NOT NULL,
                    schedule_type TEXT NOT NULL,
                    schedule_time TEXT NOT NULL,
                    emails TEXT,
                    active BOOLEAN DEFAULT 1,
                    last_run TIMESTAMP,
                    next_run TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.commit()
    
    def initialize_database(self):
        """Public method to initialize database (for compatibility with start.py)."""
        self._init_database()
    
    @contextmanager
    def get_connection(self):
        """Get database connection with proper cleanup."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        # Fix for Python 3.12 datetime adapter deprecation warning
        sqlite3.register_adapter(datetime.datetime, lambda dt: dt.isoformat())
        try:
            yield conn
        finally:
            conn.close()
    
    def auto_flush_analysis_results(self, max_rows=100, max_age_days=30):
        """Delete old analysis results, keeping only the most recent max_rows or those newer than max_age_days."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            # Delete by age
            cursor.execute("""
                DELETE FROM analysis_results
                WHERE created_at < datetime('now', ?)
            """, (f'-{max_age_days} days',))
            # Delete by row count (keep only most recent max_rows)
            cursor.execute(f"""
                DELETE FROM analysis_results
                WHERE id NOT IN (
                    SELECT id FROM analysis_results ORDER BY created_at DESC LIMIT ?
                )
            """, (max_rows,))
            conn.commit()

    def store_analysis_result(self, analysis_type: str, table_names: List[str], 
                            sql_query: Optional[str], analysis_result: Dict[str, Any], 
                            metrics: Optional[Dict[str, Any]] = None) -> int:
        """Store analysis result in database, auto-flushing old results first."""
        self.auto_flush_analysis_results()  # Prune before insert
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO analysis_results 
                (analysis_type, table_names, sql_query, analysis_result, metrics)
                VALUES (?, ?, ?, ?, ?)
            """, (
                analysis_type,
                ','.join(table_names),
                sql_query,
                str(analysis_result),
                str(metrics) if metrics else None
            ))
            conn.commit()
            lastrowid = cursor.lastrowid
            if lastrowid is None:
                raise RuntimeError("Failed to insert analysis result, no rowid returned.")
            return lastrowid
    
    def get_analysis_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get analysis history."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, analysis_type, table_names, created_at, status, metrics
                FROM analysis_results
                ORDER BY created_at DESC
                LIMIT ?
            """, (limit,))
            
            results = []
            for row in cursor.fetchall():
                results.append({
                    'id': row['id'],
                    'analysis_type': row['analysis_type'],
                    'table_names': row['table_names'],
                    'created_at': row['created_at'],
                    'status': row['status'],
                    'metrics': row['metrics']
                })
            return results
    
    def get_analysis_by_id(self, analysis_id: int) -> Optional[Dict[str, Any]]:
        """Get specific analysis result by ID."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM analysis_results WHERE id = ?
            """, (analysis_id,))
            
            row = cursor.fetchone()
            if row:
                return {
                    'id': row['id'],
                    'analysis_type': row['analysis_type'],
                    'table_names': row['table_names'],
                    'sql_query': row['sql_query'],
                    'analysis_result': row['analysis_result'],
                    'metrics': row['metrics'],
                    'created_at': row['created_at'],
                    'status': row['status']
                }
            return None
    
    def delete_analysis(self, analysis_id: int) -> bool:
        """Delete analysis result by ID."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM analysis_results WHERE id = ?", (analysis_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    def create_custom_rule(self, rule_data: Dict[str, Any]) -> int:
        """Create a new custom rule."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO custom_rules 
                (name, description, rule_type, category, severity, query, active)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                rule_data['name'],
                rule_data.get('description'),
                rule_data['type'],
                rule_data['category'],
                rule_data['severity'],
                rule_data['query'],
                rule_data.get('active', True)
            ))
            conn.commit()
            lastrowid = cursor.lastrowid
            if lastrowid is None:
                raise RuntimeError("Failed to insert custom rule, no rowid returned.")
            return lastrowid

    def get_custom_rules(self) -> List[Dict[str, Any]]:
        """Get all custom rules."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM custom_rules ORDER BY created_at DESC")
            
            results = []
            for row in cursor.fetchall():
                results.append({
                    'id': row['id'],
                    'name': row['name'],
                    'description': row['description'],
                    'type': row['rule_type'],
                    'category': row['category'],
                    'severity': row['severity'],
                    'active': bool(row['active']),
                    'created_at': row['created_at']
                })
            return results
    
    def update_custom_rule(self, rule_id: int, rule_data: Dict[str, Any]) -> bool:
        """Update an existing custom rule."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE custom_rules 
                SET name = ?, description = ?, rule_type = ?, category = ?, 
                    severity = ?, query = ?, active = ?
                WHERE id = ?
            """, (
                rule_data['name'],
                rule_data.get('description'),
                rule_data['type'],
                rule_data['category'],
                rule_data['severity'],
                rule_data['query'],
                rule_data.get('active', True),
                rule_id
            ))
            conn.commit()
            return cursor.rowcount > 0
    
    def delete_custom_rule(self, rule_id: int) -> bool:
        """Delete a custom rule."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM custom_rules WHERE id = ?", (rule_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    def create_scheduled_job(self, job_data: Dict[str, Any]) -> int:
        """Create a new scheduled job."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO scheduled_jobs 
                (name, description, catalog, schema, tables, analysis_types, 
                 schedule_type, schedule_time, emails, active, next_run)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                job_data['name'],
                job_data.get('description'),
                job_data['catalog'],
                job_data['schema'],
                ','.join(job_data['tables']),
                ','.join(job_data['analysis_types']),
                job_data['schedule_type'],
                job_data['schedule_time'],
                job_data.get('emails'),
                job_data.get('active', True),
                job_data.get('next_run')
            ))
            conn.commit()
            lastrowid = cursor.lastrowid
            if lastrowid is None:
                raise RuntimeError("Failed to insert scheduled job, no rowid returned.")
            return lastrowid
    
    def get_scheduled_jobs(self) -> List[Dict[str, Any]]:
        """Get all scheduled jobs."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM scheduled_jobs ORDER BY created_at DESC")
            
            results = []
            for row in cursor.fetchall():
                results.append({
                    'id': row['id'],
                    'name': row['name'],
                    'description': row['description'],
                    'catalog': row['catalog'],
                    'schema': row['schema'],
                    'tables': row['tables'].split(',') if row['tables'] else [],
                    'analysis_types': row['analysis_types'].split(',') if row['analysis_types'] else [],
                    'schedule_type': row['schedule_type'],
                    'schedule_time': row['schedule_time'],
                    'active': bool(row['active']),
                    'last_run': row['last_run'],
                    'next_run': row['next_run'],
                    'created_at': row['created_at']
                })
            return results
    
    def update_scheduled_job(self, job_id: int, job_data: Dict[str, Any]) -> bool:
        """Update an existing scheduled job."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE scheduled_jobs 
                SET name = ?, description = ?, catalog = ?, schema = ?, 
                    tables = ?, analysis_types = ?, schedule_type = ?, 
                    schedule_time = ?, emails = ?, active = ?, next_run = ?
                WHERE id = ?
            """, (
                job_data['name'],
                job_data.get('description'),
                job_data['catalog'],
                job_data['schema'],
                ','.join(job_data['tables']),
                ','.join(job_data['analysis_types']),
                job_data['schedule_type'],
                job_data['schedule_time'],
                job_data.get('emails'),
                job_data.get('active', True),
                job_data.get('next_run'),
                job_id
            ))
            conn.commit()
            return cursor.rowcount > 0
    
    def delete_scheduled_job(self, job_id: int) -> bool:
        """Delete a scheduled job."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM scheduled_jobs WHERE id = ?", (job_id,))
            conn.commit()
            return cursor.rowcount > 0

# Global database manager instance
db_manager = DatabaseManager() 