from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

class AnalysisType(str, Enum):
    DATA_QUALITY = "data_quality"
    COMPLIANCE = "compliance"
    PERFORMANCE = "performance"
    SECURITY = "security"
    GENERAL = "general"
    NORMALIZATION = "normalization"
    DENORMALIZATION = "denormalization"
    RELATIONSHIPS = "relationships"
    NAMING = "naming"
    STANDARDS = "standards"
    DATA_TYPES = "data_types"
    PARTITIONING = "partitioning"
    CONSTRAINTS = "constraints"
    DOCUMENTATION = "documentation"
    GOVERNANCE = "governance"
    PII_DETECTION = "pii_detection"
    PCI_COMPLIANCE = "pci_compliance"
    GDPR_COMPLIANCE = "gdpr_compliance"
    ML_READINESS = "ml_readiness"
    DATA_LINEAGE = "data_lineage"
    COST_OPTIMIZATION = "cost_optimization"
    DATA_CATALOG = "data_catalog"
    ETL_PIPELINE = "etl_pipeline"
    AUDIT_TRAIL = "audit_trail"
    DATA_RETENTION = "data_retention"
    DISASTER_RECOVERY = "disaster_recovery"
    DATA_MIGRATION = "data_migration"

class TableSelection(BaseModel):
    catalog: str = Field(..., description="Catalog name")
    schema_name: str = Field(..., description="Schema name")
    name: str = Field(..., description="Table name")
    full_name: Optional[str] = Field(None, description="Full table name (catalog.schema.table)")

class AnalysisRequest(BaseModel):
    selected_tables: List[TableSelection] = Field(..., description="List of selected tables for analysis")
    analysis_type: AnalysisType = Field(AnalysisType.GENERAL, description="Type of analysis to perform")
    sql_query: Optional[str] = Field(None, description="Optional SQL query for analysis")
    custom_rules: Optional[List[str]] = Field(None, description="List of custom rule IDs to apply")

class AnalysisResponse(BaseModel):
    success: bool = Field(..., description="Whether the analysis was successful")
    analysis_id: Optional[int] = Field(None, description="ID of the stored analysis result")
    results: Optional[Dict[str, Any]] = Field(None, description="Analysis results")
    metrics: Optional[Dict[str, Any]] = Field(None, description="Performance metrics")
    error: Optional[str] = Field(None, description="Error message if analysis failed")

class CatalogResponse(BaseModel):
    catalogs: List[str] = Field(..., description="List of available catalogs")
    analysis_types: List[str] = Field(..., description="Available analysis types")
    analysis_categories: List[str] = Field(..., description="Available analysis categories")

class SchemaResponse(BaseModel):
    schemas: List[str] = Field(..., description="List of schemas in the catalog")

class TableResponse(BaseModel):
    tables: List[str] = Field(..., description="List of tables in the schema")

class ColumnResponse(BaseModel):
    columns: List[Dict[str, Any]] = Field(..., description="List of columns in the table")

class AnalysisHistory(BaseModel):
    id: int = Field(..., description="Analysis ID")
    analysis_type: str = Field(..., description="Type of analysis performed")
    table_names: str = Field(..., description="Comma-separated list of analyzed tables")
    created_at: datetime = Field(..., description="When the analysis was created")
    status: str = Field(..., description="Analysis status")
    metrics: Optional[Dict[str, Any]] = Field(None, description="Performance metrics")

class JobRequest(BaseModel):
    job_name: str = Field(..., description="Name of the scheduled job")
    job_description: Optional[str] = Field(None, description="Job description")
    job_catalog: str = Field(..., description="Target catalog")
    job_schema: str = Field(..., description="Target schema")
    job_tables: List[str] = Field(..., description="List of tables to analyze")
    job_analysis_types: List[str] = Field(..., description="Types of analysis to perform")
    job_schedule_type: str = Field(..., description="Schedule type (daily, weekly, monthly)")
    job_schedule_time: str = Field(..., description="Time to run the job")
    job_emails: Optional[str] = Field(None, description="Email addresses for notifications")
    job_active: bool = Field(True, description="Whether the job is active")

class JobResponse(BaseModel):
    success: bool = Field(..., description="Whether the operation was successful")
    job_id: Optional[int] = Field(None, description="ID of the created/updated job")
    message: Optional[str] = Field(None, description="Response message")

class JobListResponse(BaseModel):
    jobs: List[Dict[str, Any]] = Field(..., description="List of scheduled jobs")

class RuleRequest(BaseModel):
    rule_name: str = Field(..., description="Name of the custom rule")
    rule_description: Optional[str] = Field(None, description="Rule description")
    rule_type: str = Field(..., description="Type of rule")
    rule_category: str = Field(..., description="Rule category")
    rule_severity: str = Field(..., description="Rule severity level")
    rule_query: str = Field(..., description="SQL query for the rule")
    rule_active: bool = Field(True, description="Whether the rule is active")

class RuleResponse(BaseModel):
    success: bool = Field(..., description="Whether the operation was successful")
    rule_id: Optional[int] = Field(None, description="ID of the created/updated rule")
    message: Optional[str] = Field(None, description="Response message")

class RuleListResponse(BaseModel):
    rules: List[Dict[str, Any]] = Field(..., description="List of custom rules")

class RuleValidationRequest(BaseModel):
    query: str = Field(..., description="SQL query to validate")

class RuleValidationResponse(BaseModel):
    valid: bool = Field(..., description="Whether the query is valid")

class HealthResponse(BaseModel):
    status: str = Field(..., description="API health status")
    databricks_connected: bool = Field(..., description="Whether Databricks is connected")
    database_connected: bool = Field(..., description="Whether database is connected")
    timestamp: datetime = Field(..., description="Health check timestamp") 