from fastapi import APIRouter
from .analysis_api import router as analysis_router
from .jobs import router as job_router
from .rules import router as rule_router
from .utils import router as utility_router

router = APIRouter()

router.include_router(utility_router)
router.include_router(analysis_router)
router.include_router(job_router)
router.include_router(rule_router) 