from fastapi import APIRouter, HTTPException, status
from .models import RuleRequest, RuleResponse, RuleListResponse, RuleValidationRequest, RuleValidationResponse
from .services import rule_service

router = APIRouter()

@router.post("/rules", response_model=RuleResponse)
async def create_rule(request: RuleRequest):
    """Create a new custom rule."""
    try:
        rule_data = request.dict()
        rule_id = rule_service.create_rule(rule_data)
        return RuleResponse(success=True, rule_id=rule_id, message="Rule created successfully")
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/rules", response_model=RuleListResponse)
async def get_rules():
    """Get all custom rules."""
    try:
        rules = rule_service.get_rules()
        return RuleListResponse(rules=rules)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.put("/rules/{rule_id}", response_model=RuleResponse)
async def update_rule(rule_id: int, request: RuleRequest):
    """Update an existing rule."""
    try:
        rule_data = request.dict()
        success = rule_service.update_rule(rule_id, rule_data)
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Rule not found"
            )
        return RuleResponse(success=True, rule_id=rule_id, message="Rule updated successfully")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.delete("/rules/{rule_id}", response_model=RuleResponse)
async def delete_rule(rule_id: int):
    """Delete a rule."""
    try:
        success = rule_service.delete_rule(rule_id)
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Rule not found"
            )
        return RuleResponse(success=True, message="Rule deleted successfully")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.post("/rules/validate", response_model=RuleValidationResponse)
async def validate_rule_query(request: RuleValidationRequest):
    """Validate a rule SQL query."""
    try:
        is_valid = rule_service.validate_rule_query(request.query)
        return RuleValidationResponse(valid=is_valid)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        ) 