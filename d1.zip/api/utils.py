import datetime
from fastapi import APIRouter, HTTPException, status
from .models import CatalogResponse, SchemaResponse, TableResponse, ColumnResponse, HealthResponse
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import db
from config import ANALYSIS_TYPES, ANALYSIS_CATEGORIES

router = APIRouter()

@router.get("/", response_model=CatalogResponse)
async def index():
    """Home page - show schema selection UI."""
    catalogs_data = db.get_catalogs()
    # Convert to list of strings if it's a list of dicts
    catalogs = [cat['name'] if isinstance(cat, dict) else str(cat) for cat in catalogs_data]
    return CatalogResponse(
        catalogs=catalogs,
        analysis_types=list(ANALYSIS_TYPES.keys()),
        analysis_categories=list(set(ANALYSIS_CATEGORIES))
    )

@router.get("/get_schemas/{catalog_name}", response_model=SchemaResponse)
async def get_schemas(catalog_name: str):
    """Get schemas for a selected catalog."""
    try:
        schemas_data = db.get_schemas(catalog_name)
        # Convert to list of strings if it's a list of dicts
        schemas = [schema['name'] if isinstance(schema, dict) else str(schema) for schema in schemas_data]
        return SchemaResponse(schemas=schemas)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/get_tables/{catalog_name}/{schema_name}", response_model=TableResponse)
async def get_tables(catalog_name: str, schema_name: str):
    """Get tables for a selected schema."""
    try:
        tables = db.get_tables(catalog_name, schema_name)
        return TableResponse(tables=tables)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/get_columns/{catalog_name}/{schema_name}/{table_name}", response_model=ColumnResponse)
async def get_columns(catalog_name: str, schema_name: str, table_name: str):
    """Get columns for a selected table."""
    try:
        columns = db.get_columns(catalog_name, schema_name, table_name)
        return ColumnResponse(columns=columns)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/databricks_status")
async def databricks_status():
    """Check Databricks connection status."""
    try:
        is_connected = db.test_connection()
        return {"connected": is_connected}
    except Exception as e:
        return {"connected": False, "error": str(e)}

@router.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    try:
        databricks_connected = db.test_connection()
        database_connected = True  # SQLite is always available
        return HealthResponse(
            status="healthy" if databricks_connected and database_connected else "degraded",
            databricks_connected=databricks_connected,
            database_connected=database_connected,
            timestamp=datetime.datetime.now()
        )
    except Exception as e:
        return HealthResponse(
            status="unhealthy",
            databricks_connected=False,
            database_connected=False,
            timestamp=datetime.datetime.now()
        ) 