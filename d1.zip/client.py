import requests
from config import AI_API_KEY, AI_API_URL
from utils import clean_spark_assist_output, get_sample_analysis

def estimate_tokens(text):
    """
    Estimate token count conservatively (3.5 chars per token).
    """
    if not text:
        return 0
    return len(text) // 3.5

def validate_prompt_tokens(prompt, max_tokens=4000):
    """
    Validate that prompt doesn't exceed token limit.
    Returns truncated prompt if needed.
    """
    estimated_tokens = estimate_tokens(prompt)
    if estimated_tokens <= max_tokens:
        return prompt
    # Truncate to fit within limit
    max_chars = max_tokens * 3.5
    truncated = prompt[:int(max_chars)]
    print(f"[WARNING] Prompt truncated from {estimated_tokens} to {estimate_tokens(truncated)} tokens")
    return truncated

def get_spark_assist_analysis(prompt):
    """
    Send a prompt to the Gemini API and return the cleaned HTML result.
    """
    try:
        # Validate and truncate prompt if needed
        validated_prompt = validate_prompt_tokens(prompt, max_tokens=4000)
        params = {
            'key': AI_API_KEY,
        }
        request_body = {
            "contents": [
                {
                    "parts": [
                        {"text": validated_prompt}
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "topK": 32,
                "topP": 0.95,
                "maxOutputTokens": 8192,
            }
        }
        if not AI_API_KEY:
            return get_sample_analysis()
        response = requests.post(
            AI_API_URL,
            params=params,
            json=request_body,
            headers={"Content-Type": "application/json"},
            verify=False
        )
        response_json = response.json()
        # Extract the actual text from Gemini's response
        text = ""
        if (
            isinstance(response_json, dict)
            and "candidates" in response_json
            and isinstance(response_json["candidates"], list)
            and len(response_json["candidates"]) > 0
            and "content" in response_json["candidates"][0]
            and "parts" in response_json["candidates"][0]["content"]
            and isinstance(response_json["candidates"][0]["content"]["parts"], list)
            and len(response_json["candidates"][0]["content"]["parts"]) > 0
            and "text" in response_json["candidates"][0]["content"]["parts"][0]
        ):
            text = response_json["candidates"][0]["content"]["parts"][0]["text"]
        else:
            text = str(response_json)
        return clean_spark_assist_output(text)
    except Exception as e:
        print(f"[Gemini] ERROR: {e}")
        return f"[ERROR] Gemini LLM call failed: {e}" 