import os
from pathlib import Path
# from dotenv import load_dotenv

# Remove environment variable loading
# load_dotenv()

# Hardcoded API Keys and credentials
DATABRICKS_SERVER = 'dbc-c4bcb4ff-42c3.cloud.databricks.com'
DATABRICKS_HTTP_PATH = '/sql/1.0/warehouses/00198f5dffa8e667'
DATABRICKS_TOKEN = 'dapi5658454fbe4c2e4b715aa9c1511065a0'

# Gemini API integration settings
AI_API_KEY = 'AIzaSyDMXDsC-1MB6t0lePDQeCD_zTbGr2bYsEU'
AI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent'

# Database settings
DATABASE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data.db')

# Cache settings
CACHE_TTL_SECONDS = 3600  # 1 hour

# Analysis types available in the application
ANALYSIS_TYPES = {
    'general': {
        'name': 'General Schema Analysis', 
        'value': 'general',
        'description': 'Overview of tables, relationships, primary/foreign keys, and general recommendations.',
        'category': 'core_analysis'
    },
    'performance': {
        'name': 'Performance Optimization', 
        'value': 'performance',
        'description': 'Identifies performance bottlenecks, indexing opportunities, and query optimization suggestions.',
        'category': 'performance_optimization'
    },
    'normalization': {
        'name': 'Normalization Assessment', 
        'value': 'normalization',
        'description': 'Evaluates database normalization, identifies redundancies, and suggests improvements.',
        'category': 'core_analysis'
    },
    'denormalization': {
        'name': 'Denormalization Analysis', 
        'value': 'denormalization',
        'description': 'Analyzes denormalization opportunities, trade-offs, and performance implications.',
        'category': 'performance_optimization'
    },
    'relationships': {
        'name': 'Relationship Analysis', 
        'value': 'relationships',
        'description': 'Focuses on entity relationships, cardinality, and referential integrity issues.',
        'category': 'core_analysis'
    },
    'naming': {
        'name': 'Naming Convention Review', 
        'value': 'naming',
        'description': 'Reviews consistency of naming patterns and suggests standards-based improvements.',
        'category': 'core_analysis'
    },
    'data_types': {
        'name': 'Data Type Optimization', 
        'value': 'data_types',
        'description': 'Analyzes data type choices, storage efficiency, and type conversion opportunities.',
        'category': 'performance_optimization'
    },
    'partitioning': {
        'name': 'Partitioning Strategy', 
        'value': 'partitioning',
        'description': 'Evaluates partitioning and clustering strategies for large tables in Databricks.',
        'category': 'performance_optimization'
    },
    'constraints': {
        'name': 'Constraint Analysis', 
        'value': 'constraints',
        'description': 'Reviews primary keys, foreign keys, check constraints, and data integrity rules.',
        'category': 'core_analysis'
    },
    'documentation': {
        'name': 'Documentation Quality', 
        'value': 'documentation',
        'description': 'Assesses table and column comments, metadata completeness, and documentation standards.',
        'category': 'governance_compliance'
    },
    'security': {
        'name': 'Security & Access Control', 
        'value': 'security',
        'description': 'Analyzes column-level security, row-level security, and access control patterns.',
        'category': 'governance_compliance'
    },
    'data_quality': {
        'name': 'Data Quality Assessment', 
        'value': 'data_quality',
        'description': 'Evaluates data quality rules, validation patterns, and data governance practices.',
        'category': 'governance_compliance'
    },
    'pii_detection': {
        'name': 'PII Data Detection', 
        'value': 'pii_detection',
        'description': 'Identifies Personally Identifiable Information (PII) fields and suggests privacy controls.',
        'category': 'advanced_analysis'
    },
    'pci_compliance': {
        'name': 'PCI/DSS Compliance', 
        'value': 'pci_compliance',
        'description': 'Assesses Payment Card Industry Data Security Standard compliance requirements.',
        'category': 'advanced_analysis'
    },
    'gdpr_compliance': {
        'name': 'GDPR Compliance', 
        'value': 'gdpr_compliance',
        'description': 'Evaluates General Data Protection Regulation compliance and data privacy requirements.',
        'category': 'advanced_analysis'
    },
    'ml_readiness': {
        'name': 'ML Data Readiness', 
        'value': 'ml_readiness',
        'description': 'Assesses data readiness for machine learning, including feature engineering opportunities.',
        'category': 'advanced_analysis'
    },
    'data_lineage': {
        'name': 'Data Lineage Tracking', 
        'value': 'data_lineage',
        'description': 'Maps data flow, transformations, and dependencies across the data pipeline.',
        'category': 'advanced_analysis'
    },
    'cost_optimization': {
        'name': 'Cost Optimization', 
        'value': 'cost_optimization',
        'description': 'Analyzes storage costs, compute optimization, and resource utilization patterns.',
        'category': 'advanced_analysis'
    },
    'data_catalog': {
        'name': 'Data Catalog Structure', 
        'value': 'data_catalog',
        'description': 'Evaluates metadata organization, data discovery, and catalog completeness.',
        'category': 'advanced_analysis'
    },
    'etl_pipeline': {
        'name': 'ETL Pipeline Analysis', 
        'value': 'etl_pipeline',
        'description': 'Assesses Extract, Transform, Load pipeline efficiency and data transformation patterns.',
        'category': 'advanced_analysis'
    },
    'data_governance': {
        'name': 'Data Governance Framework', 
        'value': 'data_governance',
        'description': 'Evaluates data governance policies, roles, responsibilities, and compliance frameworks.',
        'category': 'advanced_analysis'
    },
    'audit_trail': {
        'name': 'Audit Trail Analysis', 
        'value': 'audit_trail',
        'description': 'Assesses audit logging, change tracking, and compliance monitoring capabilities.',
        'category': 'advanced_analysis'
    },
    'data_retention': {
        'name': 'Data Retention Policy', 
        'value': 'data_retention',
        'description': 'Evaluates data retention policies, archival strategies, and lifecycle management.',
        'category': 'advanced_analysis'
    },
    'disaster_recovery': {
        'name': 'Disaster Recovery Readiness', 
        'value': 'disaster_recovery',
        'description': 'Assesses backup strategies, recovery procedures, and business continuity planning.',
        'category': 'advanced_analysis'
    },
    'data_migration': {
        'name': 'Data Migration Assessment', 
        'value': 'data_migration',
        'description': 'Evaluates migration complexity, data mapping, and transformation requirements.',
        'category': 'advanced_analysis'
    }
}

# Diagram templates for each analysis type
DIAGRAM_TEMPLATES = {
    'general': {
        'description': 'ER diagram showing table relationships and basic schema structure',
        'template': '''erDiagram
    %% ER diagram syntax - no classDef styling
    %% Each table should be defined with its columns
    %% Relationships should use ||--o{ or }o--|| syntax
    
    TABLE1 {
        string id PK
        string name
        string description
    }
    
    TABLE2 {
        string id PK
        string table1_id FK
        string value
    }
    
    TABLE1 ||--o{ TABLE2 : "has many"
    
    %% Add more tables and relationships based on actual schema
    %% Use ||--|| for one-to-one, ||--o{ for one-to-many, }o--o{ for many-to-many'''
    },
    
    'normalization': {
        'description': 'ER diagram showing normalization levels and dependencies',
        'template': '''erDiagram
    %% Normalization analysis - show before/after normalization
    %% BEFORE: Denormalized table
    ORDERS_DENORMALIZED {
        string order_id PK
        string customer_name
        string customer_email
        string product_name
        string product_category
        int quantity
        decimal price
    }
    
    %% AFTER: Normalized tables
    CUSTOMERS {
        string customer_id PK
        string customer_name
        string customer_email
    }
    
    PRODUCTS {
        string product_id PK
        string product_name
        string product_category
        decimal price
    }
    
    ORDERS {
        string order_id PK
        string customer_id FK
        string product_id FK
        int quantity
    }
    
    CUSTOMERS ||--o{ ORDERS : "places"
    PRODUCTS ||--o{ ORDERS : "ordered_in"'''
    },
    
    'denormalization': {
        'description': 'ER diagram showing denormalization opportunities and performance trade-offs',
        'template': '''erDiagram
    %% Denormalization analysis - show performance vs normalization trade-offs
    %% Original normalized structure
    USERS {
        string user_id PK
        string username
        string email
    }
    
    USER_PROFILES {
        string profile_id PK
        string user_id FK
        string first_name
        string last_name
        string bio
    }
    
    USER_PREFERENCES {
        string preference_id PK
        string user_id FK
        string preference_key
        string preference_value
    }
    
    %% Denormalized for performance
    USERS_DENORMALIZED {
        string user_id PK
        string username
        string email
        string first_name
        string last_name
        string bio
        string preferences_json
    }
    
    USERS ||--|| USER_PROFILES : "has"
    USERS ||--o{ USER_PREFERENCES : "has"
    
    %% Show denormalization benefits and trade-offs'''
    },
    
    'performance': {
        'description': 'Flowchart showing performance optimization strategies and bottlenecks',
        'template': '''graph TD
    %% Performance analysis flowchart
    %% Use exact syntax - no special characters
    A[Query Execution] --> B{Index Available?}
    B -->|Yes| C[Use Index]
    B -->|No| D[Full Table Scan]
    
    C --> E[Fast Execution]
    D --> F[Slow Execution]
    
    F --> G{Partition Available?}
    G -->|Yes| H[Use Partition]
    G -->|No| I[Optimize Query]
    
    H --> E
    I --> J[Add Indexes]
    J --> E
    
    E --> K[Results Returned]
    
    %% Add more performance optimization paths'''
    },
    
    'relationships': {
        'description': 'ER diagram focusing on foreign key relationships and cardinality',
        'template': '''erDiagram
    %% Relationship analysis - focus on foreign keys and cardinality
    %% Use exact cardinality notation
    DEPARTMENTS {
        string dept_id PK
        string dept_name
        string location
    }
    
    EMPLOYEES {
        string emp_id PK
        string dept_id FK
        string manager_id FK
        string name
        string position
    }
    
    PROJECTS {
        string project_id PK
        string dept_id FK
        string project_name
        string status
    }
    
    EMPLOYEE_PROJECTS {
        string emp_id FK
        string project_id FK
        string role
    }
    
    %% Show different relationship types
    DEPARTMENTS ||--o{ EMPLOYEES : "employs"
    DEPARTMENTS ||--o{ PROJECTS : "manages"
    EMPLOYEES ||--o{ EMPLOYEES : "manages"
    EMPLOYEES }o--o{ PROJECTS : "works_on"'''
    },
    
    'naming': {
        'description': 'Conceptual diagram showing naming convention patterns and violations',
        'template': '''graph LR
    %% Naming convention analysis
    %% Use exact syntax - no special characters
    A[Good Naming] --> B[snake_case]
    A --> C[PascalCase]
    A --> D[camelCase]
    
    E[Bad Naming] --> F[UPPER_CASE]
    E --> G[no_spaces]
    E --> H[123prefix]
    
    I[Table Names] --> J[users]
    I --> K[user_profiles]
    I --> L[order_items]
    
    M[Column Names] --> N[user_id]
    M --> O[created_at]
    M --> P[is_active]
    
    %% Show naming patterns and violations'''
    },
    
    'standards': {
        'description': 'Hierarchy diagram showing compliance with architectural standards',
        'template': '''graph TD
    %% Standards compliance hierarchy
    %% Use exact syntax - no special characters
    A[Architectural Standards] --> B[Data Quality]
    A --> C[Security]
    A --> D[Performance]
    A --> E[Scalability]
    
    B --> F[Completeness]
    B --> G[Accuracy]
    B --> H[Consistency]
    
    C --> I[Encryption]
    C --> J[Access Control]
    C --> K[Audit Logging]
    
    D --> L[Indexing]
    D --> M[Partitioning]
    D --> N[Query Optimization]
    
    E --> O[Horizontal Scaling]
    E --> P[Vertical Scaling]
    E --> Q[Load Balancing]
    
    %% Add compliance status indicators'''
    },
    
    'governance': {
        'description': 'Flowchart showing data governance processes and compliance checks',
        'template': '''graph TD
    %% Data governance process flow
    %% Use exact syntax - no special characters
    A[Data Input] --> B[Classification]
    B --> C{PII Data?}
    C -->|Yes| D[Apply Privacy Controls]
    C -->|No| E[Standard Processing]
    
    D --> F[Encryption]
    D --> G[Access Restrictions]
    D --> H[Audit Logging]
    
    E --> I[Quality Checks]
    F --> I
    G --> I
    H --> I
    
    I --> J{Compliance Check}
    J -->|Pass| K[Data Available]
    J -->|Fail| L[Data Remediation]
    
    L --> I
    K --> M[Usage Monitoring]
    
    %% Show governance workflow'''
    },
    
    'architecture_assessment': {
        'description': 'Multi-layered architecture diagram showing 20+ standards assessment',
        'template': '''graph TD
    %% 20+ Architecture Standards Assessment
    %% Use exact syntax - no special characters
    A[Enterprise Architecture] --> B[Data Layer]
    A --> C[Application Layer]
    A --> D[Infrastructure Layer]
    
    B --> E[Data Quality Standards]
    B --> F[Security Standards]
    B --> G[Privacy Standards]
    B --> H[Performance Standards]
    
    C --> I[Integration Standards]
    C --> J[Testing Standards]
    C --> K[Documentation Standards]
    C --> L[Versioning Standards]
    
    D --> M[Scalability Standards]
    D --> N[Reliability Standards]
    D --> O[Monitoring Standards]
    D --> P[Cost Optimization]
    
    %% Add compliance status for each standard
    E --> Q[Compliant]
    F --> R[Needs Review]
    G --> S[Non-Compliant]
    H --> T[Compliant]
    
    %% Show assessment results'''
    },
    
    'tree_of_tables': {
        'description': 'Hierarchy diagram showing tree-of-tables decomposition and relationships',
        'template': '''graph TD
    %% Tree-of-Tables Analysis
    %% Use exact syntax - no special characters
    A[Root Table] --> B[Level 1 - Core]
    A --> C[Level 1 - Metadata]
    A --> D[Level 1 - Relationships]
    
    B --> E[Level 2 - Primary Keys]
    B --> F[Level 2 - Business Data]
    B --> G[Level 2 - Derived Data]
    
    C --> H[Level 2 - Audit Info]
    C --> I[Level 2 - Technical Metadata]
    C --> J[Level 2 - Business Metadata]
    
    D --> K[Level 2 - Foreign Keys]
    D --> L[Level 2 - Junction Tables]
    D --> M[Level 2 - Lookup Tables]
    
    %% Show hierarchical decomposition
    E --> N[Leaf Node - ID Fields]
    F --> O[Leaf Node - Core Business Data]
    G --> P[Leaf Node - Calculated Fields]
    
    %% Add context preservation indicators'''
    },
    
    'machine_learning': {
        'description': 'Flowchart showing ML data pipeline and model lifecycle',
        'template': '''graph TD
    %% Machine Learning Pipeline - Use actual table names from schema
    A[Raw Data<br/>Customer Reviews, Sales Data] --> B[Data Preprocessing<br/>Cleaning, Normalization]
    B --> C[Feature Engineering<br/>Text Features, Numerical Features]
    C --> D[Model Training<br/>Train/Test Split, Cross-Validation]
    D --> E[Model Evaluation<br/>Accuracy, Precision, Recall]
    E --> F{Performance<br/>OK?}
    F -->|No| G[Hyperparameter Tuning<br/>Grid Search, Random Search]
    F -->|Yes| H[Model Deployment<br/>Production Environment]
    G --> D
    H --> I[Model Monitoring<br/>Performance Tracking]
    I --> J[Data Drift Detection<br/>Distribution Changes]
    J --> K{Drift<br/>Detected?}
    K -->|Yes| L[Retrain Model<br/>New Data]
    K -->|No| I
    L --> D
    
    %% Subgraphs for different data types
    subgraph "Text Processing Pipeline"
        A --> A1[Text Data<br/>media_customer_reviews]
        A1 --> B1[Text Preprocessing<br/>Tokenization, Lemmatization]
        B1 --> C1[Text Features<br/>TF-IDF, Word Embeddings]
        C1 --> D
    end
    
    subgraph "Numerical Processing Pipeline"
        A --> A2[Numerical Data<br/>sales_customers, sales_suppliers]
        A2 --> B2[Numerical Preprocessing<br/>Scaling, Encoding]
        B2 --> C2[Numerical Features<br/>Aggregations, Ratios]
        C2 --> D
    end
    
    %% Styling
    classDef dataStyle fill:#e3f2fd
    classDef processStyle fill:#f3e5f5
    classDef decisionStyle fill:#fff3e0
    classDef modelStyle fill:#e8f5e8
    classDef monitorStyle fill:#fce4ec
    
    class A,A1,A2 dataStyle
    class B,B1,B2,C,C1,C2 processStyle
    class F,K decisionStyle
    class D,E,G,H,L modelStyle
    class I,J monitorStyle'''
    },
    
    'data_engineering': {
        'description': 'Flowchart showing ETL/ELT pipeline and data transformation process',
        'template': '''graph TD
    %% Data Engineering Pipeline - Use actual table names from schema
    A[Source Systems<br/>Supplier DB, Customer Reviews] --> B[Data Extraction]
    B --> C{Data Validation<br/>supplierID, review_date}
    C -->|No| D[Data Cleansing<br/>Address Standardization]
    D --> C
    C -->|Yes| E[Data Transformation<br/>Aggregation, Joins]
    E --> F[Data Loading<br/>Data Warehouse]
    F --> G[Data Warehouse<br/>Fact Tables, Dimension Tables]
    G --> H[Data Marts<br/>Sales Reports, Customer Analysis]
    H --> I[Business Intelligence<br/>Dashboards, Reports]
    
    %% Subgraphs for different data sources
    subgraph "Sales Suppliers ETL"
        B --> B1[Extract sales_suppliers]
        B1 --> C
        C -->|Yes| E
    end
    
    subgraph "Customer Reviews ETL"
        B --> B2[Extract media_customer_reviews]
        B2 --> C
        C -->|Yes| E
    end
    
    subgraph "Customer Data ETL"
        B --> B3[Extract sales_customers]
        B3 --> C
        C -->|Yes| E
    end
    
    subgraph "Chunked Reviews ETL"
        B --> B4[Extract media_gold_reviews_chunked]
        B4 --> C
        C -->|Yes| E
    end
    
    %% Styling
    classDef sourceStyle fill:#e1f5fe
    classDef processStyle fill:#f3e5f5
    classDef decisionStyle fill:#fff3e0
    classDef storageStyle fill:#e8f5e8
    classDef outputStyle fill:#fce4ec
    
    class A sourceStyle
    class B,E processStyle
    class C decisionStyle
    class F,G,H storageStyle
    class I outputStyle'''
    },
    
    'data_lineage': {
        'description': 'Flowchart showing data lineage and transformation tracking',
        'template': '''graph LR
    %% Data Lineage Tracking
    %% Use exact syntax - no special characters
    A[Source Table 1] --> B[ETL Process 1]
    A --> C[ETL Process 2]
    B --> D[Intermediate Table 1]
    C --> E[Intermediate Table 2]
    D --> F[Final Table 1]
    E --> F
    F --> G[Business Report]
    
    %% Show data flow and dependencies'''
    },
    
    'data_catalog': {
        'description': 'Hierarchy diagram showing data catalog structure and metadata organization',
        'template': '''graph TD
    %% Data Catalog Structure
    %% Use exact syntax - no special characters
    A[Data Catalog] --> B[Business Glossary]
    A --> C[Technical Metadata]
    A --> D[Data Assets]
    
    B --> E[Business Terms]
    B --> F[Data Definitions]
    B --> G[Business Rules]
    
    C --> H[Schema Information]
    C --> I[Data Types]
    C --> J[Constraints]
    
    D --> K[Tables]
    D --> L[Views]
    D --> M[Stored Procedures]
    
    %% Show catalog organization'''
    },
    
    'data_ops': {
        'description': 'Flowchart showing DataOps CI/CD pipeline and automation',
        'template': '''graph TD
    %% DataOps CI/CD Pipeline
    %% Use exact syntax - no special characters
    A[Code Commit] --> B[Automated Testing]
    B --> C{Tests Pass?}
    C -->|No| D[Fix Issues]
    C -->|Yes| E[Build Pipeline]
    D --> B
    E --> F[Deploy to Dev]
    F --> G[Integration Tests]
    G --> H{Tests Pass?}
    H -->|No| I[Rollback]
    H -->|Yes| J[Deploy to Prod]
    I --> D
    J --> K[Monitor Production]
    
    %% Show DataOps workflow'''
    },
    
    'data_types': {
        'description': 'ER diagram showing data type analysis and optimization opportunities',
        'template': '''erDiagram
    %% Data type optimization analysis
    %% Show current vs optimized data types
    TABLE_CURRENT {
        string id PK
        string name
        string status
        string created_date
        string amount
    }
    
    TABLE_OPTIMIZED {
        int id PK
        varchar name
        enum status
        date created_date
        decimal amount
    }
    
    %% Show data type conversion benefits
    %% Include storage savings and performance improvements'''
    },
    
    'partitioning': {
        'description': 'Flowchart showing partitioning strategy analysis and recommendations',
        'template': '''graph TD
    %% Partitioning strategy analysis
    A[Table Analysis] --> B{Table Size}
    B -->|Large| C[Consider Partitioning]
    B -->|Small| D[No Partitioning Needed]
    
    C --> E{Partition Column?}
    E -->|Date/Time| F[Time-based Partitioning]
    E -->|Category| G[Hash Partitioning]
    E -->|None| H[Range Partitioning]
    
    F --> I[Partition by Year/Month]
    G --> J[Partition by Hash]
    H --> K[Partition by Range]
    
    I --> L[Improved Query Performance]
    J --> L
    K --> L
    
    D --> M[Standard Table]
    L --> N[Optimized Table]'''
    },
    
    'constraints': {
        'description': 'ER diagram showing constraint analysis and data integrity rules',
        'template': '''erDiagram
    %% Constraint analysis - show primary keys, foreign keys, and constraints
    CUSTOMERS {
        int customer_id PK
        string customer_name
        string email UNIQUE
        string phone
    }
    
    ORDERS {
        int order_id PK
        int customer_id FK
        date order_date
        decimal total_amount
    }
    
    ORDER_ITEMS {
        int item_id PK
        int order_id FK
        int product_id FK
        int quantity CHECK
        decimal unit_price
    }
    
    CUSTOMERS ||--o{ ORDERS : "places"
    ORDERS ||--o{ ORDER_ITEMS : "contains"
    
    %% Show constraint types and their purposes'''
    },
    
    'documentation': {
        'description': 'Conceptual diagram showing documentation quality assessment',
        'template': '''graph LR
    %% Documentation quality analysis
    A[Table Documentation] --> B[Table Comments]
    A --> C[Column Comments]
    A --> D[Business Rules]
    
    E[Documentation Quality] --> F[Complete]
    E --> G[Partial]
    E --> H[Missing]
    
    I[Metadata] --> J[Data Dictionary]
    I --> K[Lineage Info]
    I --> L[Usage Patterns]
    
    M[Recommendations] --> N[Add Comments]
    M --> O[Update Metadata]
    M --> P[Create Documentation]'''
    },
    
    'security': {
        'description': 'Flowchart showing security and access control analysis',
        'template': '''graph TD
    %% Security and access control analysis
    A[Data Classification] --> B{PII Data?}
    B -->|Yes| C[Apply Privacy Controls]
    B -->|No| D[Standard Security]
    
    C --> E[Column-level Security]
    C --> F[Row-level Security]
    C --> G[Encryption]
    
    D --> H[Basic Access Control]
    D --> I[Role-based Security]
    
    E --> J[Secure Data Access]
    F --> J
    G --> J
    H --> K[Standard Access]
    I --> K
    
    J --> L[Compliant Access]
    K --> M[Regular Access]'''
    },
    
    'data_quality': {
        'description': 'Flowchart showing data quality assessment and validation rules',
        'template': '''graph TD
    %% Data quality assessment
    A[Data Quality Check] --> B[Completeness]
    A --> C[Accuracy]
    A --> D[Consistency]
    A --> E[Validity]
    
    B --> F{Null Values?}
    F -->|Yes| G[Data Completeness Issue]
    F -->|No| H[Complete Data]
    
    C --> I{Data Accuracy?}
    I -->|No| J[Accuracy Issue]
    I -->|Yes| K[Accurate Data]
    
    D --> L{Consistent Format?}
    L -->|No| M[Consistency Issue]
    L -->|Yes| N[Consistent Data]
    
    E --> O{Valid Values?}
    O -->|No| P[Validity Issue]
    O -->|Yes| Q[Valid Data]
    
    G --> R[Data Quality Issues]
    J --> R
    M --> R
    P --> R
    
    H --> S[Quality Data]
    K --> S
    N --> S
    Q --> S'''
    },
    
    'pii_detection': {
        'description': 'Flowchart showing PII detection and classification process',
        'template': '''graph TD
    %% PII Detection Analysis
    A[Data Field Analysis] --> B{Contains PII?}
    B -->|Yes| C[Classify PII Type]
    B -->|No| D[Non-PII Data]
    
    C --> E[Personal Identifiers]
    C --> F[Contact Information]
    C --> G[Financial Data]
    C --> H[Biometric Data]
    C --> I[Location Data]
    
    E --> J[Apply Privacy Controls]
    F --> J
    G --> J
    H --> J
    I --> J
    
    J --> K[Encryption]
    J --> L[Access Restrictions]
    J --> M[Audit Logging]
    
    D --> N[Standard Processing]
    K --> O[Secure Data]
    L --> O
    M --> O
    N --> P[Regular Data]'''
    },
    
    'pci_compliance': {
        'description': 'Flowchart showing PCI/DSS compliance assessment',
        'template': '''graph TD
    %% PCI/DSS Compliance Analysis
    A[PCI Compliance Check] --> B{Contains Card Data?}
    B -->|Yes| C[Cardholder Data Environment]
    B -->|No| D[Non-PCI Scope]
    
    C --> E[Build Secure Network]
    C --> F[Protect Cardholder Data]
    C --> G[Maintain Vulnerability Management]
    C --> H[Implement Access Controls]
    C --> I[Monitor & Test Networks]
    C --> J[Maintain Security Policy]
    
    E --> K[Network Segmentation]
    F --> L[Encryption & Tokenization]
    G --> M[Security Updates]
    H --> N[Access Management]
    I --> O[Monitoring & Testing]
    J --> P[Security Policies]
    
    K --> Q[PCI Compliant]
    L --> Q
    M --> Q
    N --> Q
    O --> Q
    P --> Q
    
    D --> R[Standard Security]'''
    },
    
    'gdpr_compliance': {
        'description': 'Flowchart showing GDPR compliance assessment',
        'template': '''graph TD
    %% GDPR Compliance Analysis
    A[GDPR Compliance Check] --> B{Contains Personal Data?}
    B -->|Yes| C[Personal Data Processing]
    B -->|No| D[Non-GDPR Scope]
    
    C --> E[Lawful Basis]
    C --> F[Data Subject Rights]
    C --> G[Data Protection]
    C --> H[Data Minimization]
    C --> I[Accountability]
    
    E --> J[Consent/Legitimate Interest]
    F --> K[Right to Access/Delete]
    G --> L[Encryption & Security]
    H --> I[Minimal Data Collection]
    I --> M[Documentation & Records]
    
    J --> N[GDPR Compliant]
    K --> N
    L --> N
    M --> N
    
    D --> O[Standard Processing]'''
    },
    
    'ml_readiness': {
        'description': 'Flowchart showing ML data readiness assessment',
        'template': '''graph TD
    %% ML Data Readiness Analysis
    A[ML Readiness Assessment] --> B[Data Quality]
    A --> C[Feature Engineering]
    A --> D[Data Volume]
    A --> E[Data Diversity]
    
    B --> F{High Quality?}
    F -->|Yes| G[Quality Data]
    F -->|No| H[Data Cleaning Needed]
    
    C --> I{Features Available?}
    I -->|Yes| J[Feature Rich]
    I -->|No| K[Feature Engineering Needed]
    
    D --> L{Sufficient Volume?}
    L -->|Yes| M[Adequate Data]
    L -->|No| N[More Data Needed]
    
    E --> O{Diverse Data?}
    O -->|Yes| P[Diverse Dataset]
    O -->|No| Q[Data Augmentation Needed]
    
    G --> R[ML Ready]
    J --> R
    M --> R
    P --> R
    
    H --> S[Preprocessing Required]
    K --> S
    N --> S
    Q --> S'''
    },
    
    'data_lineage': {
        'description': 'Flowchart showing data lineage tracking and dependencies',
        'template': '''graph LR
    %% Data Lineage Analysis
    A[Source Systems] --> B[Data Ingestion]
    B --> C[Data Lake]
    C --> D[Data Processing]
    D --> E[Data Warehouse]
    E --> F[Analytics Layer]
    F --> G[Business Intelligence]
    
    H[Lineage Tracking] --> I[Source to Target]
    H --> J[Transformation Logic]
    H --> K[Data Dependencies]
    H --> L[Impact Analysis]
    
    M[Metadata Management] --> N[Data Catalog]
    M --> O[Schema Evolution]
    M --> P[Version Control]
    
    Q[Monitoring] --> R[Data Quality Checks]
    Q --> S[Performance Metrics]
    Q --> T[Error Tracking]'''
    },
    
    'cost_optimization': {
        'description': 'Flowchart showing cost optimization strategies',
        'template': '''graph TD
    %% Cost Optimization Analysis
    A[Cost Analysis] --> B[Storage Costs]
    A --> C[Compute Costs]
    A --> D[Network Costs]
    A --> E[License Costs]
    
    B --> F{Storage Optimization?}
    F -->|Yes| G[Compression & Archival]
    F -->|No| H[Storage Review Needed]
    
    C --> I{Compute Optimization?}
    I -->|Yes| J[Resource Scaling]
    I -->|No| K[Compute Review Needed]
    
    D --> L{Network Optimization?}
    L -->|Yes| M[Data Locality]
    L -->|No| N[Network Review Needed]
    
    E --> O{License Optimization?}
    O -->|Yes| P[License Management]
    O -->|No| Q[License Review Needed]
    
    G --> R[Cost Optimized]
    J --> R
    M --> R
    P --> R
    
    H --> S[Cost Reduction Plan]
    K --> S
    N --> S
    Q --> S'''
    },
    
    'data_catalog': {
        'description': 'Conceptual diagram showing data catalog structure',
        'template': '''graph LR
    %% Data Catalog Structure
    A[Data Catalog] --> B[Metadata Management]
    A --> C[Data Discovery]
    A --> D[Business Glossary]
    A --> E[Data Lineage]
    
    B --> F[Schema Information]
    B --> G[Data Quality Metrics]
    B --> H[Usage Statistics]
    
    C --> I[Search & Browse]
    C --> J[Data Profiling]
    C --> K[Data Classification]
    
    D --> L[Business Terms]
    D --> M[Data Definitions]
    D --> N[Data Ownership]
    
    E --> O[Source to Target]
    E --> P[Transformation Logic]
    E --> Q[Impact Analysis]'''
    },
    
    'etl_pipeline': {
        'description': 'Flowchart showing ETL pipeline analysis',
        'template': '''graph TD
    %% ETL Pipeline Analysis
    A[ETL Pipeline] --> B[Extract]
    A --> C[Transform]
    A --> D[Load]
    
    B --> E{Source Systems}
    E --> F[Data Extraction]
    F --> G[Data Validation]
    
    C --> H[Data Transformation]
    H --> I[Data Cleansing]
    I --> J[Data Enrichment]
    J --> K[Data Aggregation]
    
    D --> L[Target Systems]
    L --> M[Data Loading]
    M --> N[Data Verification]
    
    O[Pipeline Monitoring] --> P[Performance Metrics]
    O --> Q[Error Handling]
    O --> R[Data Quality Checks]
    
    S[Optimization] --> T[Parallel Processing]
    S --> U[Incremental Loading]
    S --> V[Resource Optimization]'''
    },
    
    'data_governance': {
        'description': 'Hierarchy diagram showing data governance framework',
        'template': '''graph TD
    %% Data Governance Framework
    A[Data Governance] --> B[Policies & Standards]
    A --> C[Roles & Responsibilities]
    A --> D[Processes & Procedures]
    A --> E[Technology & Tools]
    
    B --> F[Data Classification]
    B --> G[Data Quality Standards]
    B --> H[Security Policies]
    B --> I[Retention Policies]
    
    C --> J[Data Stewards]
    C --> K[Data Owners]
    C --> L[Data Custodians]
    C --> M[Data Users]
    
    D --> N[Data Lifecycle Management]
    D --> O[Change Management]
    D --> P[Incident Management]
    D --> Q[Compliance Monitoring]
    
    E --> R[Data Catalog Tools]
    E --> S[Quality Monitoring]
    E --> T[Security Controls]
    E --> U[Audit Tools]'''
    },
    
    'audit_trail': {
        'description': 'Flowchart showing audit trail analysis',
        'template': '''graph TD
    %% Audit Trail Analysis
    A[Audit Trail] --> B[Data Access Logs]
    A --> C[Change Tracking]
    A --> D[User Activity]
    A --> E[System Events]
    
    B --> F[Who Accessed Data]
    B --> G[When Data Was Accessed]
    B --> H[What Data Was Accessed]
    B --> I[How Data Was Used]
    
    C --> J[Schema Changes]
    C --> K[Data Modifications]
    C --> L[Configuration Changes]
    C --> M[Policy Updates]
    
    D --> N[User Authentication]
    D --> O[User Authorization]
    D --> P[User Actions]
    D --> Q[Session Management]
    
    E --> R[System Performance]
    E --> S[Error Logging]
    E --> T[Security Events]
    E --> U[Compliance Events]'''
    },
    
    'data_retention': {
        'description': 'Flowchart showing data retention policy analysis',
        'template': '''graph TD
    %% Data Retention Policy Analysis
    A[Data Retention] --> B[Data Classification]
    A --> C[Retention Periods]
    A --> D[Archival Strategy]
    A --> E[Deletion Process]
    
    B --> F[Critical Data]
    B --> G[Important Data]
    B --> H[Regular Data]
    B --> I[Temporary Data]
    
    C --> J[Legal Requirements]
    C --> K[Business Requirements]
    C --> L[Regulatory Requirements]
    C --> M[Operational Needs]
    
    D --> N[Active Storage]
    D --> O[Archive Storage]
    D --> P[Cold Storage]
    D --> Q[Backup Storage]
    
    E --> R[Automated Deletion]
    E --> S[Manual Review]
    E --> T[Compliance Verification]
    E --> U[Audit Trail]'''
    },
    
    'disaster_recovery': {
        'description': 'Flowchart showing disaster recovery readiness assessment',
        'template': '''graph TD
    %% Disaster Recovery Analysis
    A[Disaster Recovery] --> B[Backup Strategy]
    A --> C[Recovery Procedures]
    A --> D[Business Continuity]
    A --> E[Testing & Validation]
    
    B --> F[Full Backups]
    B --> G[Incremental Backups]
    B --> H[Differential Backups]
    B --> I[Point-in-Time Recovery]
    
    C --> J[Recovery Time Objectives]
    C --> K[Recovery Point Objectives]
    C --> L[Recovery Procedures]
    C --> M[Failover Processes]
    
    D --> N[Business Impact Analysis]
    D --> O[Critical Systems]
    D --> P[Data Prioritization]
    D --> Q[Communication Plans]
    
    E --> R[Regular Testing]
    E --> S[Recovery Drills]
    E --> T[Documentation Updates]
    E --> U[Training Programs]'''
    },
    
    'data_migration': {
        'description': 'Flowchart showing data migration assessment',
        'template': '''graph TD
    %% Data Migration Analysis
    A[Data Migration] --> B[Migration Planning]
    A --> C[Data Assessment]
    A --> D[Migration Strategy]
    A --> E[Validation & Testing]
    
    B --> F[Source Analysis]
    B --> G[Target Analysis]
    B --> H[Timeline Planning]
    B --> I[Resource Planning]
    
    C --> J[Data Profiling]
    C --> K[Data Quality Assessment]
    C --> L[Data Mapping]
    C --> M[Transformation Rules]
    
    D --> N[Big Bang Migration]
    D --> O[Phased Migration]
    D --> P[Parallel Migration]
    D --> Q[Incremental Migration]
    
    E --> R[Data Validation]
    E --> S[Performance Testing]
    E --> T[User Acceptance Testing]
    E --> U[Rollback Planning]'''
    }
}

# Analysis categories for organizing analysis types
ANALYSIS_CATEGORIES = {
    'core_analysis': {
        'name': 'Core Analysis',
        'description': 'Fundamental database and schema analysis',
        'types': ['general', 'normalization', 'relationships', 'naming', 'constraints', 'data_types']
    },
    'performance_optimization': {
        'name': 'Performance & Optimization',
        'description': 'Performance analysis and optimization recommendations',
        'types': ['performance', 'denormalization', 'partitioning', 'cost_optimization']
    },
    'governance_compliance': {
        'name': 'Governance & Compliance',
        'description': 'Data governance, compliance, and security standards',
        'types': ['documentation', 'security', 'data_quality', 'data_governance', 'audit_trail', 'data_retention']
    },
    'advanced_analysis': {
        'name': 'Advanced Analysis',
        'description': 'Specialized analysis techniques for complex scenarios',
        'types': ['pii_detection', 'pci_compliance', 'gdpr_compliance', 'ml_readiness', 'data_lineage', 'data_catalog', 'etl_pipeline', 'disaster_recovery', 'data_migration']
    }
}

# 20+ Architectural Standards for Data Governance & Compliance
ARCHITECTURAL_STANDARDS = {
    'data_quality': {
        'name': 'Data Quality Standards',
        'description': 'Ensures data accuracy, completeness, consistency, and timeliness',
        'checks': [
            'Data completeness validation',
            'Data accuracy verification',
            'Data consistency across tables',
            'Data freshness and timeliness',
            'Data lineage tracking'
        ]
    },
    'security': {
        'name': 'Security Standards',
        'description': 'Protects data through encryption, access controls, and audit trails',
        'checks': [
            'Column-level encryption',
            'Row-level security implementation',
            'Access control policies',
            'Audit logging and monitoring',
            'Data masking for sensitive fields'
        ]
    },
    'privacy': {
        'name': 'Privacy Standards',
        'description': 'Ensures compliance with privacy regulations (GDPR, CCPA, etc.)',
        'checks': [
            'PII identification and classification',
            'Data retention policies',
            'Right to be forgotten implementation',
            'Consent management tracking',
            'Data anonymization techniques'
        ]
    },
    'performance': {
        'name': 'Performance Standards',
        'description': 'Optimizes query performance and resource utilization',
        'checks': [
            'Partitioning strategies',
            'Clustering optimization',
            'Index usage analysis',
            'Query performance monitoring',
            'Resource utilization tracking'
        ]
    },
    'scalability': {
        'name': 'Scalability Standards',
        'description': 'Ensures system can handle growth in data volume and users',
        'checks': [
            'Horizontal scaling capabilities',
            'Vertical scaling considerations',
            'Data distribution strategies',
            'Load balancing implementation',
            'Capacity planning metrics'
        ]
    },
    'maintainability': {
        'name': 'Maintainability Standards',
        'description': 'Ensures code and data structures are easy to maintain and modify',
        'checks': [
            'Documentation quality',
            'Code modularity',
            'Naming conventions',
            'Version control practices',
            'Change management processes'
        ]
    },
    'reliability': {
        'name': 'Reliability Standards',
        'description': 'Ensures system availability and fault tolerance',
        'checks': [
            'Backup and recovery procedures',
            'Disaster recovery planning',
            'High availability configuration',
            'Error handling mechanisms',
            'Monitoring and alerting'
        ]
    },
    'compliance': {
        'name': 'Compliance Standards',
        'description': 'Ensures adherence to industry and regulatory requirements',
        'checks': [
            'SOX compliance for financial data',
            'HIPAA compliance for healthcare data',
            'PCI DSS for payment data',
            'Industry-specific regulations',
            'Internal policy compliance'
        ]
    },
    'data_governance': {
        'name': 'Data Governance Standards',
        'description': 'Establishes policies and procedures for data management',
        'checks': [
            'Data ownership and stewardship',
            'Data classification policies',
            'Data lifecycle management',
            'Data catalog implementation',
            'Governance framework adherence'
        ]
    },
    'integration': {
        'name': 'Integration Standards',
        'description': 'Ensures seamless integration with other systems and tools',
        'checks': [
            'API design and documentation',
            'Data format standardization',
            'Integration testing procedures',
            'Error handling in integrations',
            'Monitoring of integration health'
        ]
    },
    'monitoring': {
        'name': 'Monitoring Standards',
        'description': 'Provides comprehensive observability and alerting',
        'checks': [
            'Performance metrics collection',
            'Error rate monitoring',
            'Resource utilization tracking',
            'Business metrics monitoring',
            'Alert and notification systems'
        ]
    },
    'testing': {
        'name': 'Testing Standards',
        'description': 'Ensures data quality through comprehensive testing',
        'checks': [
            'Unit testing for data transformations',
            'Integration testing for data pipelines',
            'Data quality testing procedures',
            'Regression testing processes',
            'Test data management'
        ]
    },
    'documentation': {
        'name': 'Documentation Standards',
        'description': 'Ensures comprehensive and up-to-date documentation',
        'checks': [
            'Schema documentation quality',
            'API documentation completeness',
            'Process and procedure documentation',
            'Change log maintenance',
            'User guide and training materials'
        ]
    },
    'versioning': {
        'name': 'Versioning Standards',
        'description': 'Manages changes and maintains version history',
        'checks': [
            'Schema versioning strategies',
            'API versioning policies',
            'Data migration procedures',
            'Rollback capabilities',
            'Change tracking and audit trails'
        ]
    },
    'cost_optimization': {
        'name': 'Cost Optimization Standards',
        'description': 'Optimizes resource usage and costs',
        'checks': [
            'Storage optimization strategies',
            'Compute resource optimization',
            'Query cost analysis',
            'Resource scheduling optimization',
            'Cost monitoring and alerting'
        ]
    },
    'data_lineage': {
        'name': 'Data Lineage Standards',
        'description': 'Tracks data flow and transformations',
        'checks': [
            'End-to-end data lineage tracking',
            'Transformation logic documentation',
            'Impact analysis capabilities',
            'Lineage visualization tools',
            'Metadata management'
        ]
    },
    'data_catalog': {
        'name': 'Data Catalog Standards',
        'description': 'Maintains comprehensive data inventory and metadata',
        'checks': [
            'Data asset inventory',
            'Metadata management',
            'Data discovery capabilities',
            'Business glossary maintenance',
            'Catalog search and navigation'
        ]
    },
    'data_modeling': {
        'name': 'Data Modeling Standards',
        'description': 'Ensures proper data structure and relationships',
        'checks': [
            'Normalization level assessment',
            'Entity relationship modeling',
            'Dimensional modeling practices',
            'Data warehouse design principles',
            'Model documentation quality'
        ]
    },
    'data_engineering': {
        'name': 'Data Engineering Standards',
        'description': 'Ensures robust data pipeline development',
        'checks': [
            'ETL/ELT process design',
            'Data pipeline orchestration',
            'Error handling and recovery',
            'Data transformation logic',
            'Pipeline monitoring and alerting'
        ]
    },
    'machine_learning': {
        'name': 'Machine Learning Standards',
        'description': 'Ensures proper ML model development and deployment',
        'checks': [
            'Feature engineering practices',
            'Model versioning and tracking',
            'Model performance monitoring',
            'A/B testing capabilities',
            'Model explainability and interpretability'
        ]
    },
    'data_ops': {
        'name': 'DataOps Standards',
        'description': 'Implements DevOps practices for data operations',
        'checks': [
            'Automated testing and deployment',
            'Continuous integration/continuous deployment',
            'Environment management',
            'Release management processes',
            'Collaboration and communication tools'
        ]
    }
}