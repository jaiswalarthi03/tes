import os
import datetime
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from api.routes import router
from api.db import db_manager

# Initialize FastAPI app
app = FastAPI(
    title="ADW Data Modeller API",
    description="Production-grade API for data modeling assessment and analysis",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Security middleware
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"]
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(router, prefix="/api/v1")

# Serve React build files
if os.path.exists("build"):
    app.mount("/static", StaticFiles(directory="build/static"), name="static")

@app.get("/")
async def root():
    """Serve the React application."""
    if os.path.exists("build/index.html"):
        return FileResponse("build/index.html")
    else:
        return {"message": "React build not found. Run 'npm run build' first."}

@app.get("/{full_path:path}")
async def serve_react_app(full_path: str):
    """Serve React app for all other routes (SPA routing)."""
    if os.path.exists("build/index.html"):
        return FileResponse("build/index.html")
    else:
        return {"message": "React build not found. Run 'npm run build' first."}

@app.middleware("http")
async def log_request_info(request: Request, call_next):
    """Log request information."""
    # Only log significant requests, not static files or basic page loads
    if not request.url.path.startswith('/static/') and request.url.path != '/':
        print(f"🔄 {request.method} {request.url.path}")
    
    response = await call_next(request)
    return response

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "status_code": exc.status_code,
            "timestamp": datetime.datetime.now().isoformat()
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions."""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc),
            "timestamp": datetime.datetime.now().isoformat()
        }
    )

@app.on_event("startup")
async def startup_event():
    """Initialize application on startup."""
    print("🚀 Starting ADW Data Modeller API...")
    print("📊 Initializing database...")
    # Database is initialized in DatabaseManager.__init__()
    print("✅ Database initialized")
    print("🔗 Testing Databricks connection...")
    try:
        import db
        if db.test_connection():
            print("✅ Databricks connected")
        else:
            print("⚠️  Databricks connection failed")
    except Exception as e:
        print(f"❌ Databricks connection error: {e}")
    print("🎯 API ready!")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    print("🛑 Shutting down ADW Data Modeller API...")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    ) 