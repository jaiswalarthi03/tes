# Production Run Commands

## 1. Backend (Python)
```sh
# Install Python dependencies
pip install -r requirements.txt

# Start the backend server
python main.py
```

## 2. Frontend (Node/React)
```sh
# Install Node.js dependencies
npm install

# (Optional) Build the frontend for production
npm run build

# (If running a development server)
npm start
``` 