import React, { useState, useEffect, useCallback } from 'react';
import apiService from './api';
import DataTable from './components/DataTable';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import Analysis from './components/Analysis';
import History from './components/History';
import Rules from './components/Rules';
import Jobs from './components/Jobs';
import AppOverlays from './components/AppOverlays';
import Footer from './components/Footer';
import JobModal from './components/JobModal';
import RuleModal from './components/RuleModal';
import { TableIcon, ClockIcon, PlusIcon, ShieldIcon } from './components/Icons';
import RefreshIcon from '@mui/icons-material/Refresh';

const App = () => {
  const [currentView, setCurrentView] = useState('analysis');
  const [apiStatus, setApiStatus] = useState('Checking...');
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState(null);
  const [showJobModal, setShowJobModal] = useState(false);
  const [showRuleModal, setShowRuleModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isBatchRunning, setIsBatchRunning] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [showProgressionModal, setShowProgressionModal] = useState(false);
  const [progressionData, setProgressionData] = useState([]);
  const [progressionDataset, setProgressionDataset] = useState('');
  const [databricksStatus, setDatabricksStatus] = useState('Checking...');
  const [isDatabricksConnected, setIsDatabricksConnected] = useState(false);

  // Real data states
  const [jobs, setJobs] = useState([]);
  const [jobsLoading, setJobsLoading] = useState(false);
  const [jobsError, setJobsError] = useState(null);
  const [rules, setRules] = useState([]);
  const [rulesLoading, setRulesLoading] = useState(false);
  const [rulesError, setRulesError] = useState(null);
  const [datasets, setDatasets] = useState([]);
  const [datasetsLoading, setDatasetsLoading] = useState(false);
  const [datasetsError, setDatasetsError] = useState(null);
  const [tierCounts, setTierCounts] = useState({ Diamond: 0, Amber: 0, Ivory: 0, Carbon: 0 });

  useEffect(() => {
    checkHealth();
    fetchJobs();
    fetchRules();
    fetchDatasets();
    checkDatabricks();
  }, []);

  const checkHealth = async () => {
    setIsLoading(true);
    try {
      const healthData = await apiService.checkHealth();
      setIsConnected(healthData.databricks_connected);
      setApiStatus(healthData.status);
      setError(null);
    } catch (error) {
      setIsConnected(false);
      setApiStatus('FastAPI Disconnected');
      setError('Unable to connect to the FastAPI server. Please ensure the server is running on port 8000.');
    } finally {
      setIsLoading(false);
    }
  };

  const checkDatabricks = async () => {
    try {
      const status = await apiService.checkHealth();
      if (status.databricks_connected) {
        setIsDatabricksConnected(true);
        setDatabricksStatus('Databricks Warehouse: Connected');
      } else {
        setIsDatabricksConnected(false);
        setDatabricksStatus('Databricks Service Down');
      }
    } catch (error) {
      setIsDatabricksConnected(false);
      setDatabricksStatus('Databricks Service Down');
    }
  };

  const fetchJobs = async () => {
    setJobsLoading(true);
    setJobsError(null);
    try {
      const data = await apiService.getJobs();
      setJobs(data);
    } catch (err) {
      setJobsError('Failed to load jobs.');
    } finally {
      setJobsLoading(false);
    }
  };

  const fetchRules = async () => {
    setRulesLoading(true);
    setRulesError(null);
    try {
      const data = await apiService.getRules();
      setRules(data);
    } catch (err) {
      setRulesError('Failed to load rules.');
    } finally {
      setRulesLoading(false);
    }
  };

  const fetchDatasets = async () => {
    setDatasetsLoading(true);
    setDatasetsError(null);
    try {
      const data = await apiService.getAnalysisHistory();
      const history = data.history || [];
      setDatasets(history);
      // Calculate tier counts if possible
      const counts = { Diamond: 0, Amber: 0, Ivory: 0, Carbon: 0 };
      history.forEach(d => {
        if (d.tier && counts[d.tier] !== undefined) counts[d.tier]++;
      });
      setTierCounts(counts);
    } catch (err) {
      setDatasetsError('Failed to load datasets.');
    } finally {
      setDatasetsLoading(false);
    }
  };

  const handleNavClick = (view) => {
    setCurrentView(view);
  };

  // TODO: Replace with real progression data from API if available
  const handleTierClick = useCallback((datasetName) => {
    setProgressionDataset(datasetName);
    setProgressionData([]); // No real progression data yet
    setShowProgressionModal(true);
  }, []);

  return (
    <div className="app-container">
      <AppOverlays
        isLoading={isLoading || jobsLoading || rulesLoading || datasetsLoading}
        isAnalyzing={isAnalyzing}
        isBatchRunning={isBatchRunning}
        showSuccess={showSuccess}
        setShowSuccess={setShowSuccess}
        showError={showError}
        setShowError={setShowError}
        showOnboarding={showOnboarding}
        setShowOnboarding={setShowOnboarding}
        showProgressionModal={showProgressionModal}
        setShowProgressionModal={setShowProgressionModal}
        progressionData={progressionData}
        progressionDataset={progressionDataset}
      />

      <Navbar
        currentView={currentView}
        handleNavClick={handleNavClick}
        isConnected={isConnected}
        apiStatus={apiStatus}
        databricksStatus={databricksStatus}
        isDatabricksConnected={isDatabricksConnected}
        onRefreshStatus={() => { checkHealth(); checkDatabricks(); }}
      />

      <div className="main-content">
        {currentView === 'home' && (
          <Dashboard
            tierCounts={tierCounts}
            dummyDatasets={datasets}
            handleTierClick={handleTierClick}
            TableIcon={null}
            DataTable={DataTable}
            isLoading={datasetsLoading}
            error={datasetsError}
          />
        )}

        {currentView === 'analysis' && (
          <Analysis
            tierCounts={tierCounts}
            dummyDatasets={datasets}
            handleTierClick={handleTierClick}
            TableIcon={null}
            DataTable={DataTable}
            showJobModal={showJobModal}
            setShowJobModal={setShowJobModal}
            showRuleModal={showRuleModal}
            setShowRuleModal={setShowRuleModal}
            isLoading={datasetsLoading}
            error={datasetsError}
          />
        )}

        {currentView === 'history' && (
          <History
            handleNavClick={handleNavClick}
          />
        )}

        {currentView === 'rules' && (
          <Rules
            dummyRules={rules}
            DataTable={DataTable}
            setShowRuleModal={setShowRuleModal}
            isLoading={rulesLoading}
            error={rulesError}
            onRefresh={fetchRules}
          />
        )}

        {currentView === 'jobs' && (
          <Jobs
            dummyJobs={jobs}
            DataTable={DataTable}
            setShowJobModal={setShowJobModal}
            isLoading={jobsLoading}
            error={jobsError}
            onRefresh={fetchJobs}
          />
        )}
      </div>
      
      <Footer />

      <JobModal isOpen={showJobModal} onClose={() => setShowJobModal(false)} onSuccess={fetchJobs} />
      <RuleModal isOpen={showRuleModal} onClose={() => setShowRuleModal(false)} onSuccess={fetchRules} />
    </div>
  );
};

export default App; 