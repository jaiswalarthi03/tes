import axios from 'axios';

// API base configuration
const API_BASE_URL = 'http://localhost:8000/api/v1';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 0, // Infinite timeout for long-running backend analysis
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for logging
apiClient.interceptors.request.use(
  (config) => {
    console.log(`🔄 API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('❌ API Request Error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => {
    console.log(`✅ API Response: ${response.status} ${response.config.url}`);
    return response;
  },
  (error) => {
    console.error('❌ API Response Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

// API service class
class ApiService {
  // Health and status
  async checkHealth() {
    try {
      const response = await apiClient.get('/health');
      return response.data;
    } catch (error) {
      throw new Error(`Health check failed: ${error.message}`);
    }
  }

  async checkDatabricksStatus() {
    try {
      const response = await apiClient.get('/api/databricks_status');
      return response.data;
    } catch (error) {
      throw new Error(`Databricks status check failed: ${error.message}`);
    }
  }

  // Schema discovery
  async getCatalogs() {
    try {
      const response = await apiClient.get('/');
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get catalogs: ${error.message}`);
    }
  }

  async getSchemas(catalogName) {
    try {
      const response = await apiClient.get(`/get_schemas/${catalogName}`);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get schemas: ${error.message}`);
    }
  }

  async getTables(catalogName, schemaName) {
    try {
      const response = await apiClient.get(`/get_tables/${catalogName}/${schemaName}`);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get tables: ${error.message}`);
    }
  }

  async getColumns(catalogName, schemaName, tableName) {
    try {
      const response = await apiClient.get(`/get_columns/${catalogName}/${schemaName}/${tableName}`);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get columns: ${error.message}`);
    }
  }

  // Table selection
  async getSelectedTables() {
    try {
      const response = await apiClient.get('/get_selected_tables');
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get selected tables: ${error.message}`);
    }
  }

  async clearSelection() {
    try {
      const response = await apiClient.post('/clear_selection');
      return response.data;
    } catch (error) {
      throw new Error(`Failed to clear selection: ${error.message}`);
    }
  }

  // Analysis
  async runAnalysis(selectedTables, analysisType, sqlQuery = null) {
    try {
      const requestData = {
        selected_tables: selectedTables.map(table => ({
          catalog: table.catalog,
          schema_name: table.schema || table.schema_name, // always send schema_name
          name: table.name,
          full_name: table.full_name
        })),
        analysis_type: analysisType,
        sql_query: sqlQuery
      };

      const response = await apiClient.post('/analysis', requestData);
      return response.data;
    } catch (error) {
      throw new Error(`Analysis failed: ${error.message}`);
    }
  }

  async runTreeAnalysis(selectedTables) {
    try {
      const requestData = {
        selected_tables: selectedTables.map(table => ({
          catalog: table.catalog,
          schema_name: table.schema || table.schema_name, // always send schema_name
          name: table.name,
          full_name: table.full_name
        })),
        analysis_type: 'general'
      };

      const response = await apiClient.post('/tree_analysis', requestData);
      return response.data;
    } catch (error) {
      throw new Error(`Tree analysis failed: ${error.message}`);
    }
  }

  // History
  async getAnalysisHistory() {
    try {
      const response = await apiClient.get('/history');
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get analysis history: ${error.message}`);
    }
  }

  async getAnalysisById(analysisId) {
    try {
      const response = await apiClient.get(`/history/${analysisId}`);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get analysis: ${error.message}`);
    }
  }

  async deleteAnalysis(analysisId) {
    try {
      const response = await apiClient.post(`/history/delete/${analysisId}`);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to delete analysis: ${error.message}`);
    }
  }

  async exportAnalysis(analysisId) {
    try {
      const response = await apiClient.get(`/export/${analysisId}`, {
        responseType: 'blob'
      });
      
      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `analysis_${analysisId}.json`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      return { success: true };
    } catch (error) {
      throw new Error(`Failed to export analysis: ${error.message}`);
    }
  }

  // Jobs Management
  async createJob(jobData) {
    try {
      const response = await apiClient.post('/jobs', jobData);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to create job: ${error.message}`);
    }
  }

  async getJobs() {
    try {
      const response = await apiClient.get('/jobs');
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get jobs: ${error.message}`);
    }
  }

  async updateJob(jobId, jobData) {
    try {
      const response = await apiClient.put(`/jobs/${jobId}`, jobData);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to update job: ${error.message}`);
    }
  }

  async deleteJob(jobId) {
    try {
      const response = await apiClient.delete(`/jobs/${jobId}`);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to delete job: ${error.message}`);
    }
  }

  // Rules Management
  async createRule(ruleData) {
    try {
      const response = await apiClient.post('/rules', ruleData);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to create rule: ${error.message}`);
    }
  }

  async getRules() {
    try {
      const response = await apiClient.get('/rules');
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get rules: ${error.message}`);
    }
  }

  async updateRule(ruleId, ruleData) {
    try {
      const response = await apiClient.put(`/rules/${ruleId}`, ruleData);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to update rule: ${error.message}`);
    }
  }

  async deleteRule(ruleId) {
    try {
      const response = await apiClient.delete(`/rules/${ruleId}`);
      return response.data;
    } catch (error) {
      throw new Error(`Failed to delete rule: ${error.message}`);
    }
  }

  async validateRuleQuery(query) {
    try {
      const response = await apiClient.post('/rules/validate', { query });
      return response.data;
    } catch (error) {
      throw new Error(`Failed to validate rule query: ${error.message}`);
    }
  }

  // Test tables
  async createTestTables() {
    try {
      const response = await apiClient.post('/create_test_tables');
      return response.data;
    } catch (error) {
      throw new Error(`Failed to create test tables: ${error.message}`);
    }
  }
}

// Export singleton instance
const apiService = new ApiService();
export default apiService; 