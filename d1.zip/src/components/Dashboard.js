import React from 'react';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import CardHeader from '@mui/material/CardHeader';
import CircularProgress from '@mui/material/CircularProgress';

const Dashboard = ({ tierCounts, dummyDatasets, handleTierClick, TableIcon, DataTable, isLoading, error }) => (
  <Box sx={{ px: { xs: 1, md: 4 }, py: 4, width: '100vw', maxWidth: '1800px', mx: 'auto', overflowX: 'hidden' }}>
    <Typography variant="h6" sx={{ mb: 3, display: 'flex', alignItems: 'center', fontWeight: 'bold' }}>
      <span role="img" aria-label="database" style={{ marginRight: 10 }}>
        <svg width="28" height="28" fill="currentColor" viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 5v14c0 1.66-4.03 3-9 3s-9-1.34-9-3V5"/></svg>
      </span>
      Data Standardization Tiers
    </Typography>
    {/* Tier Metrics Summary */}
    <Grid container spacing={2} sx={{ mb: 3, width: '100%' }}>
      {[{
        label: 'Diamond', color: '#1976d2', count: tierCounts.Diamond, img: '/img/diamond.png', desc: 'Exemplary Standards'
      }, {
        label: 'Amber', color: '#ffc107', count: tierCounts.Amber, img: '/img/amber.png', desc: 'Advanced Maturity'
      }, {
        label: 'Ivory', color: '#bdbdbd', count: tierCounts.Ivory, img: '/img/ivory.png', desc: 'Developing Standards'
      }, {
        label: 'Carbon', color: '#212121', count: tierCounts.Carbon, img: '/img/carbon.png', desc: 'Foundation Phase'
      }].map((tier) => (
        <Grid item xs={3} sm={3} md={3} lg={3} xl={3} key={tier.label} sx={{ display: 'flex', minWidth: 0 }}>
          <Card sx={{
            border: '1px solid #fecaca',
            borderTop: `4px solid ${tier.color}`,
            flex: 1,
            minWidth: 330,
            minHeight: 180,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            p: 3,
            height: 240,
            transition: 'box-shadow 0.3s, border-top 0.3s',
            boxShadow: '0 2px 8px rgba(220,38,38,0.04)',
            width: '100%', // hold width steady
            '&:hover': {
              borderTop: `8px solid #dc2626`,
              boxShadow: '0 6px 24px 0 rgba(220,38,38,0.12)',
              cursor: 'pointer',
            },
          }}>
            <CardContent sx={{ textAlign: 'center', flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', p: 1 }}>
              <img src={tier.img} alt={tier.label + ' tier'} style={{ height: 64, marginBottom: 8 }} />
              <Typography variant="h6" sx={{ color: tier.color, mb: 0.5, fontWeight: 700, fontSize: 36 }}>{tier.count}</Typography>
              <Typography variant="h6" sx={{ fontWeight: 'bold', mb: 0.5, color: tier.color }}>{tier.label}</Typography>
              <Typography variant="subtitle1" color="text.secondary" sx={{ fontWeight: 500, mb: 0.5 }}>{tier.desc}</Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
    {/* Dataset Analysis Table */}
    <Typography variant="h6" sx={{ mb: 3, display: 'flex', alignItems: 'center', fontWeight: 'bold' }}>
      <span role="img" aria-label="table" style={{ marginRight: 10 }}>
        <svg width="28" height="28" fill="currentColor" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18M3 15h18M9 5v14M15 5v14"/></svg>
      </span>
      Analyzed Datasets
    </Typography>
    <Card sx={{ width: '100%', mt: 2 }}>
      <CardContent sx={{ p: { xs: 1, md: 2 } }}>
        {isLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 80 }}>
            <CircularProgress size={24} />
          </Box>
        ) : error ? (
          <Typography color="error" sx={{ mb: 2, fontSize: 13 }}>{error}</Typography>
        ) :
          <Box sx={{ width: '100%' }}>
            <DataTable
              data={dummyDatasets}
              title="Datasets"
              columns={[
                { key: 'name', label: 'Dataset Name', sortable: true },
                {
                  key: 'tier',
                  label: 'Current Tier',
                  sortable: true,
                  render: (val, row) => {
                    let icon = null;
                    if (val === 'Diamond') icon = '/img/diamond.png';
                    else if (val === 'Amber') icon = '/img/amber.png';
                    else if (val === 'Ivory') icon = '/img/ivory.png';
                    else if (val === 'Carbon') icon = '/img/carbon.png';
                    return (
                      <Box sx={{ display: 'inline-flex', alignItems: 'center', cursor: 'pointer' }} onClick={() => handleTierClick(row.name)}>
                        {icon && <img src={icon} alt={val + ' icon'} style={{ width: 16, height: 16, marginRight: 4 }} />}
                        <Typography variant="caption" sx={{ fontWeight: 'bold', fontSize: 12 }}>{val}</Typography>
                      </Box>
                    );
                  }
                },
                { key: 'qualityScore', label: 'Quality Score', sortable: true, render: (val) => `${val}%` },
                { key: 'lastAnalyzed', label: 'Last Analyzed', sortable: true },
                { key: 'team', label: 'Team', sortable: true },
                { key: 'issueCount', label: 'Issues', sortable: true },
                {
                  key: 'actions',
                  label: 'Actions',
                  sortable: false,
                  render: () => (
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button variant="outlined" size="small">View</Button>
                      <Button variant="outlined" size="small" color="secondary">Re-analyze</Button>
                    </Box>
                  )
                }
              ]}
            />
          </Box>
        }
      </CardContent>
    </Card>
  </Box>
);

export default Dashboard; 