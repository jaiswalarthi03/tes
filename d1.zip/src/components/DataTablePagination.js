import React from 'react';
import { Box, IconButton, Typography, Pagination } from '@mui/material';
import { ChevronLeftIcon, ChevronRightIcon, ChevronFirstIcon, ChevronLastIcon } from './DataTableIcons';

const DataTablePagination = ({
  currentPage,
  totalPages,
  onPageChange,
  getPageNumbers
}) => {
  // If totalPages is small, show all page numbers; otherwise, use MUI Pagination
  if (totalPages <= 10) {
    return (
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mt: 2, gap: 2 }}>
        <IconButton onClick={() => onPageChange(1)} disabled={currentPage === 1} title="First page">
          <ChevronFirstIcon />
        </IconButton>
        <IconButton onClick={() => onPageChange(currentPage - 1)} disabled={currentPage === 1} title="Previous page">
          <ChevronLeftIcon />
        </IconButton>
        {getPageNumbers().map((page, index) => (
          <React.Fragment key={index}>
            {page === '...' ? (
              <Typography sx={{ mx: 1 }}>...</Typography>
            ) : (
              <IconButton
                color={currentPage === page ? 'primary' : 'default'}
                onClick={() => onPageChange(page)}
                disabled={currentPage === page}
              >
                {page}
              </IconButton>
            )}
          </React.Fragment>
        ))}
        <IconButton onClick={() => onPageChange(currentPage + 1)} disabled={currentPage === totalPages} title="Next page">
          <ChevronRightIcon />
        </IconButton>
        <IconButton onClick={() => onPageChange(totalPages)} disabled={currentPage === totalPages} title="Last page">
          <ChevronLastIcon />
        </IconButton>
        <Typography sx={{ ml: 2 }}>Page {currentPage} of {totalPages}</Typography>
      </Box>
    );
  }
  // For large page counts, use MUI Pagination
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mt: 2, gap: 2 }}>
      <Pagination
        count={totalPages}
        page={currentPage}
        onChange={(_, page) => onPageChange(page)}
        color="primary"
        showFirstButton
        showLastButton
      />
      <Typography sx={{ ml: 2 }}>Page {currentPage} of {totalPages}</Typography>
    </Box>
  );
};

export default DataTablePagination; 