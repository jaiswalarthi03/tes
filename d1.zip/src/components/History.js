import React, { useEffect, useState } from 'react';
import { Box, Grid, Button, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, IconButton, CircularProgress, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import HistoryIcon from '@mui/icons-material/History';
import AddIcon from '@mui/icons-material/Add';
import TableChartIcon from '@mui/icons-material/TableChart';
import DeleteIcon from '@mui/icons-material/Delete';
import DownloadIcon from '@mui/icons-material/Download';
import apiService from '../api/index';

const History = ({ handleNavClick }) => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchHistory = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiService.getAnalysisHistory();
      setHistory(data.history || []);
    } catch (err) {
      setError('Failed to load analysis history.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleDelete = async (id) => {
    setDeleting(true);
    try {
      await apiService.deleteAnalysis(id);
      setDeleteId(null);
      fetchHistory();
    } catch (err) {
      setError('Failed to delete analysis.');
    } finally {
      setDeleting(false);
    }
  };

  const handleExport = async (id) => {
    try {
      await apiService.exportAnalysis(id);
    } catch (err) {
      setError('Failed to export analysis.');
    }
  };

  return (
    <Box sx={{ px: { xs: 1, md: 4 }, py: 4 }}>
      <Grid container alignItems="center" justifyContent="space-between" sx={{ mb: 4 }}>
        <Grid item>
          <Typography variant="h5" sx={{ display: 'flex', alignItems: 'center', fontWeight: 'bold' }}>
            <HistoryIcon sx={{ mr: 1 }} />
            Analysis History
          </Typography>
        </Grid>
        <Grid item>
          <Button variant="contained" color="primary" startIcon={<AddIcon />} onClick={() => handleNavClick('home')}>
            New Analysis
          </Button>
        </Grid>
      </Grid>
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Box sx={{ textAlign: 'center', mt: 8 }}>
          <Typography color="error">{error}</Typography>
        </Box>
      ) : history.length === 0 ? (
        <Box sx={{ textAlign: 'center', mt: 8 }}>
          <TableChartIcon sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
          <img src="/img/chart.gif" alt="No analysis history" style={{ width: 120, margin: '0 auto' }} />
          <Typography variant="h6" sx={{ mt: 2 }}>No Analysis History</Typography>
          <Typography variant="body2" color="text.secondary">Run your first analysis to see the results here.</Typography>
        </Box>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Tables</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {history.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{new Date(row.created_at).toLocaleString()}</TableCell>
                  <TableCell>{row.analysis_type}</TableCell>
                  <TableCell>{row.table_names}</TableCell>
                  <TableCell>{row.status}</TableCell>
                  <TableCell align="right">
                    <IconButton color="primary" onClick={() => handleExport(row.id)} title="Export">
                      <DownloadIcon />
                    </IconButton>
                    <IconButton color="error" onClick={() => setDeleteId(row.id)} title="Delete">
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      <Dialog open={!!deleteId} onClose={() => setDeleteId(null)}>
        <DialogTitle>Delete Analysis</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this analysis result?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteId(null)} disabled={deleting}>Cancel</Button>
          <Button onClick={() => handleDelete(deleteId)} color="error" disabled={deleting}>
            {deleting ? <CircularProgress size={20} /> : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default History; 