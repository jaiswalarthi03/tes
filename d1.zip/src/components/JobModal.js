import React, { useState } from 'react';
import Modal from './Modal';
import { Box, Button, TextField, Select, MenuItem, FormControl, InputLabel, Checkbox, FormControlLabel, Grid, Typography, CircularProgress } from '@mui/material';
import apiService from '../api';

const JobModal = ({ isOpen, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    jobName: '',
    jobDescription: '',
    jobCatalog: '',
    jobSchema: '',
    jobTables: [],
    jobAnalysisTypes: [],
    jobCustomRules: [],
    jobScheduleType: '',
    jobScheduleTime: '',
    jobScheduleDay: '',
    jobEmails: '',
    jobActive: true
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      // Map formData to API job fields as needed
      await apiService.createJob({
        name: formData.jobName,
        description: formData.jobDescription,
        catalog: formData.jobCatalog,
        schema: formData.jobSchema,
        tables: formData.jobTables,
        analysis_types: formData.jobAnalysisTypes,
        custom_rules: formData.jobCustomRules,
        schedule_type: formData.jobScheduleType,
        schedule_time: formData.jobScheduleTime,
        schedule_day: formData.jobScheduleDay,
        emails: formData.jobEmails,
        active: formData.jobActive
      });
      if (onSuccess) onSuccess();
      onClose();
    } catch (err) {
      setError('Failed to create job.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Create Scheduled Job" size="modal-xl">
      <Box component="form" onSubmit={handleSubmit} sx={{ p: 2 }}>
        {/* Basic Information */}
        <Typography variant="h6" sx={{ mb: 2 }}>Basic Information</Typography>
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Job Name *"
              name="jobName"
              value={formData.jobName}
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Description"
              name="jobDescription"
              value={formData.jobDescription}
              onChange={handleInputChange}
              fullWidth
            />
          </Grid>
        </Grid>
        {/* Dataset Configuration */}
        <Typography variant="h6" sx={{ mb: 2 }}>Dataset Configuration</Typography>
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth required sx={{ minWidth: 480 }}>
              <InputLabel>Catalog *</InputLabel>
              <Select
                label="Catalog *"
                name="jobCatalog"
                value={formData.jobCatalog}
                onChange={handleInputChange}
              >
                <MenuItem value="">Select catalog</MenuItem>
                <MenuItem value="default">default</MenuItem>
                <MenuItem value="enterprise">enterprise</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth required sx={{ minWidth: 480 }}>
              <InputLabel>Schema *</InputLabel>
              <Select
                label="Schema *"
                name="jobSchema"
                value={formData.jobSchema}
                onChange={handleInputChange}
              >
                <MenuItem value="">Select schema</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
        {/* Schedule Configuration */}
        <Typography variant="h6" sx={{ mb: 2 }}>Schedule Configuration</Typography>
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth required sx={{ minWidth: 480 }}>
              <InputLabel>Schedule Type *</InputLabel>
              <Select
                label="Schedule Type *"
                name="jobScheduleType"
                value={formData.jobScheduleType}
                onChange={handleInputChange}
              >
                <MenuItem value="">Select schedule type</MenuItem>
                <MenuItem value="daily">Daily</MenuItem>
                <MenuItem value="weekly">Weekly</MenuItem>
                <MenuItem value="monthly">Monthly</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Time *"
              name="jobScheduleTime"
              type="time"
              value={formData.jobScheduleTime}
              onChange={handleInputChange}
              required
              fullWidth
              InputLabelProps={{ shrink: true }}
            />
          </Grid>
        </Grid>
        {/* Notification Settings */}
        <Typography variant="h6" sx={{ mb: 2 }}>Notification Settings</Typography>
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={8}>
            <TextField
              label="Email Notifications"
              name="jobEmails"
              value={formData.jobEmails}
              onChange={handleInputChange}
              placeholder="Enter email addresses (comma-separated)"
              fullWidth
              type="email"
            />
          </Grid>
          <Grid item xs={12} sm={4} sx={{ display: 'flex', alignItems: 'center' }}>
            <FormControlLabel
              control={
                <Checkbox
                  name="jobActive"
                  checked={formData.jobActive}
                  onChange={handleInputChange}
                />
              }
              label="Active"
            />
          </Grid>
        </Grid>
        {error && <Typography color="error" sx={{ mb: 2 }}>{error}</Typography>}
        {/* Form Actions */}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
          <Button variant="outlined" color="secondary" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" type="submit" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'Create Job'}
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default JobModal; 