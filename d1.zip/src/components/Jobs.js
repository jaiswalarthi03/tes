import React, { useState } from 'react';
import { Box, Grid, Button, Typography, CircularProgress, Dialog, DialogTitle, DialogContent, DialogActions, Chip } from '@mui/material';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import AddIcon from '@mui/icons-material/Add';
import apiService from '../api';

const Jobs = ({ dummyJobs, DataTable, setShowJobModal, isLoading, error, onRefresh }) => {
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState(null);

  const handleDelete = async (job) => {
    setDeleteId(job.id);
  };

  const confirmDelete = async () => {
    setDeleteLoading(true);
    setDeleteError(null);
    try {
      await apiService.deleteJob(deleteId);
      if (onRefresh) onRefresh();
      setDeleteId(null);
    } catch (err) {
      setDeleteError('Failed to delete job.');
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <Box sx={{ px: { xs: 1, md: 4 }, py: 4 }}>
      <Grid container alignItems="center" justifyContent="space-between" sx={{ mb: 4 }}>
        <Grid item>
          <Typography variant="h5" sx={{ display: 'flex', alignItems: 'center', fontWeight: 'bold' }}>
            <AccessTimeIcon sx={{ mr: 1 }} />
            Scheduled Jobs Management
          </Typography>
        </Grid>
        <Grid item>
          <Button variant="contained" color="primary" startIcon={<AddIcon />} onClick={() => setShowJobModal(true)}>
            Create New Job
          </Button>
        </Grid>
      </Grid>
      {isLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 120 }}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Typography color="error" sx={{ mb: 2 }}>{error}</Typography>
      ) : (
        <DataTable
          data={dummyJobs}
          title="Scheduled Jobs"
          onDelete={handleDelete}
          columns={[
            { key: 'id', label: 'ID', sortable: true },
            { key: 'name', label: 'Name', sortable: true },
            { key: 'schedule', label: 'Schedule', sortable: true },
            { key: 'active', label: 'Active', sortable: true, render: (val) => val ? <Chip label="Active" color="success" size="small" /> : <Chip label="Inactive" color="default" size="small" /> },
            { key: 'lastRun', label: 'Last Run', sortable: true },
            { key: 'nextRun', label: 'Next Run', sortable: true },
          ]}
        />
      )}
      <Dialog open={!!deleteId} onClose={() => setDeleteId(null)}>
        <DialogTitle>Delete Job</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this job?</Typography>
          {deleteError && <Typography color="error">{deleteError}</Typography>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteId(null)} disabled={deleteLoading}>Cancel</Button>
          <Button onClick={confirmDelete} color="error" disabled={deleteLoading}>
            {deleteLoading ? <CircularProgress size={20} /> : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Jobs; 