import React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Box from '@mui/material/Box';

const Navbar = ({ currentView, handleNavClick, isConnected, apiStatus, databricksStatus, isDatabricksConnected }) => (
  <AppBar position="static" color="default" elevation={1} sx={{ mb: 2, bgcolor: '#fff' }}>
    <Toolbar sx={{ bgcolor: '#fff' }}>
      <IconButton edge="start" color="inherit" aria-label="logo" sx={{ mr: 2 }} onClick={() => handleNavClick('home')}>
        <img src="/img/data.gif" alt="ADW Data Modeller Logo" style={{ height: 40 }} />
      </IconButton>
      <Typography variant="h5" sx={{ fontWeight: 'bold', flexGrow: 1 }}>
        <span style={{ color: '#000' }}>ADW</span> <span style={{ color: '#dc2626' }}>Data Modeller</span>
      </Typography>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <Button color={currentView === 'home' ? 'primary' : 'inherit'} onClick={() => handleNavClick('home')} sx={{ fontWeight: currentView === 'home' ? 'bold' : 'normal' }} disabled>Home</Button>
        <Button color={currentView === 'analysis' ? 'primary' : 'inherit'} onClick={() => handleNavClick('analysis')} sx={{ fontWeight: currentView === 'analysis' ? 'bold' : 'normal' }}>Analysis</Button>
        <Button color={currentView === 'rules' ? 'primary' : 'inherit'} onClick={() => handleNavClick('rules')} sx={{ fontWeight: currentView === 'rules' ? 'bold' : 'normal' }} disabled>Custom Rules</Button>
        <Button color={currentView === 'jobs' ? 'primary' : 'inherit'} onClick={() => handleNavClick('jobs')} sx={{ fontWeight: currentView === 'jobs' ? 'bold' : 'normal' }} disabled>Scheduled Jobs</Button>
        <Button color={currentView === 'history' ? 'primary' : 'inherit'} onClick={() => handleNavClick('history')} sx={{ fontWeight: currentView === 'history' ? 'bold' : 'normal' }} disabled>History</Button>
      </Box>
      <Box sx={{ ml: 3, display: 'flex', alignItems: 'center' }}>
        <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: isConnected ? 'success.main' : 'error.main', mr: 1 }} />
        <Typography variant="body2" color="text.secondary" sx={{ mr: 3 }}>{apiStatus}</Typography>
        <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: isDatabricksConnected ? 'success.main' : 'error.main', mr: 1 }} />
        <Typography variant="body2" color="text.secondary">{databricksStatus}</Typography>
      </Box>
    </Toolbar>
  </AppBar>
);

export default Navbar; 