#!/usr/bin/env python3
"""
Production startup script for ADW Data Modeller
Handles environment setup, database initialization, and server startup
"""

import os
import sys
import logging
import uvicorn
from pathlib import Path
from dotenv import load_dotenv
from db_connector import init_db

# Load environment variables
load_dotenv()

# Setup logging
def setup_logging():
    """Configure production logging."""
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=logging.ERROR,  # Only show errors
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / "app.log"),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger(__name__)

def check_environment():
    """Validate required environment variables."""
    logger = logging.getLogger(__name__)
    required_vars = [
        'DATABRICKS_SERVER',
        'DATABRICKS_HTTP_PATH', 
        'DATABRICKS_TOKEN',
        'AI_API_KEY'
    ]
    
    missing_vars = []
    for var in required_vars:
        if not os.environ.get(var):
            missing_vars.append(var)
    
    if missing_vars:
        logger.warning(f"Missing environment variables: {missing_vars}")
        logger.warning("Some features may not work properly")
    else:
        logger.info("All required environment variables are set")

def check_dependencies():
    """Check if all required dependencies are available."""
    logger = logging.getLogger(__name__)
    
    try:
        import fastapi
        import uvicorn
        import pandas
        import numpy
        logger.info("Core dependencies available")
    except ImportError as e:
        logger.error(f"Missing dependency: {e}")
        sys.exit(1)

def initialize_database():
    """Initialize database and create tables if needed."""
    logger = logging.getLogger(__name__)
    
    try:
        from api.db import db_manager
        db_manager.initialize_database()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        sys.exit(1)

def test_databricks_connection():
    """Test Databricks connection."""
    logger = logging.getLogger(__name__)
    
    try:
        import db_connector
        if db_connector.test_connection():
            logger.info("Databricks connection successful")
        else:
            logger.warning("Databricks connection failed")
    except Exception as e:
        logger.warning(f"Databricks connection error: {e}")

def main():
    """Main startup function."""
    logger = setup_logging()

    # Always initialize the database schema before anything else
    init_db()

    # logger.info("Starting ADW Data Modeller...")
    # Environment checks
    # check_environment()
    # check_dependencies()
    # Initialize components
    # initialize_database()
    # test_databricks_connection()
    # Get configuration
    host = os.environ.get('HOST', '0.0.0.0')
    port = int(os.environ.get('PORT', 8000))
    debug = os.environ.get('DEBUG', 'false').lower() == 'true'
    # logger.info(f"Starting server on {host}:{port}")
    # logger.info(f"Debug mode: {debug}")
    # Start server
    try:
        uvicorn.run(
            "main:app",
            host=host,
            port=port,
            reload=debug,
            log_level="error",
            access_log=False
        )
    except KeyboardInterrupt:
        print("🛑 Server stopped by user")
    except Exception as e:
        print(f"❌ Server startup failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 